"""
===========================================================
experiment_runner.py

Runs the A0-A3 ablation study (experiments/ablation.py)
across NUM_RUNS independent random seeds, and stores the
RAW per-segment, per-run results -- not just final summaries
-- exactly as the guideline specifies:

    "Store raw block-level results, not just averages.
     ... That is how we will diagnose problems."

Each row of the output CSV is one (run, config, segment)
record, with every field ablation.py already tracks (true
QBER, chosen p_z/p_x, requested n_test, t_epoch, qubits
used, secret key length, security status, cumulative key
buffer).

results/statistics.py consumes this CSV to compute
mean/std/95% CI and formal statistical comparisons.

Run:
    python experiment_runner.py
===========================================================
"""

import csv
import os
import random
import time

import numpy as np

import config
from experiments.ablation import CONFIGURATIONS, run_configuration, ABLATION_SCHEDULE


def run_all_seeds(num_runs=config.NUM_RUNS, base_seed=config.RANDOM_SEED):
    """
    Returns a flat list of dict rows, one per (run, config,
    segment) -- the raw, ungrouped data.
    """
    all_rows = []

    for run_idx in range(num_runs):
        seed = base_seed + run_idx

        for label, factory in CONFIGURATIONS:
            random.seed(seed)
            np.random.seed(seed)
            rng = random.Random(seed)

            controller = factory()
            rows, log = run_configuration(controller, ABLATION_SCHEDULE, rng)

            for r in rows:
                row = dict(r)
                row["run"] = run_idx
                row["seed"] = seed
                row["config"] = label
                all_rows.append(row)

        if (run_idx + 1) % 5 == 0 or run_idx == 0:
            print(f"  Completed run {run_idx + 1}/{num_runs} "
                  f"(seed={seed}) across all {len(CONFIGURATIONS)} configs")

    return all_rows


def save_raw_csv(all_rows, path="results/raw/phase7_all_runs.csv"):
    if not os.path.exists(os.path.dirname(path)):
        os.makedirs(os.path.dirname(path))

    fieldnames = [
        "run", "seed", "config", "segment", "true_qber",
        "baseline_n_rounds", "n_rounds_used", "p_z", "p_x",
        "n_test_requested", "t_epoch", "secret_length",
        "security_status", "cumulative_key_buffer",
    ]

    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in all_rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})

    print(f"\nSaved {len(all_rows)} raw rows to {path}")


def main():
    print("=" * 90)
    print(f"EXPERIMENT RUNNER: {config.NUM_RUNS} independent seeds x "
          f"{len(CONFIGURATIONS)} configurations x 5 segments")
    print("=" * 90)

    start = time.time()
    all_rows = run_all_seeds()
    elapsed = time.time() - start

    expected_rows = config.NUM_RUNS * len(CONFIGURATIONS) * 5
    print(f"\nTotal rows collected: {len(all_rows)} (expected {expected_rows})")
    print(f"Total wall-clock time: {elapsed:.1f} sec "
          f"({elapsed / config.NUM_RUNS:.2f} sec/run)")

    assert len(all_rows) == expected_rows, "Row count mismatch -- a run may have failed silently."

    save_raw_csv(all_rows)

    print("\n" + "=" * 90)
    print("EXPERIMENT RUNNER COMPLETE -- run results/statistics.py next")
    print("=" * 90)


if __name__ == "__main__":
    main()
