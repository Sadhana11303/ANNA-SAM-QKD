"""
===========================================================
results/statistics.py

Consumes results/raw/phase7_all_runs.csv (produced by
experiment_runner.py -- 30 independent runs x 4
configurations x 5 segments, raw, ungrouped) and computes:

    mu, sigma, 95% CI          -- per configuration, per metric
    Paired statistical comparisons -- A0 vs A1, A1 vs A2,
                                        A2 vs A3, A0 vs A3

Metrics compared: segments accepted (out of 5), total secret
key generated (bits), and total qubits transmitted (bits).

A PAIRED t-test is used for the comparisons (not an
independent-samples test), because each of the 30 runs uses
the SAME random seed across all four configurations -- so
run i's A0 result and run i's A1 result are naturally paired
observations of "the same random channel realization under
two different strategies", which is a more powerful and more
appropriate test than treating them as independent samples.

Run:
    python results/statistics.py
===========================================================
"""

import csv
import math
import os
import sys

import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

RAW_CSV_PATH = os.path.join(os.path.dirname(__file__), "raw", "phase7_all_runs.csv")
PROCESSED_DIR = os.path.join(os.path.dirname(__file__), "processed")

CONFIG_ORDER = ["A0_Static", "A1_AdaptiveBasis", "A2_AdaptiveBasisTest", "A3_FullANNASAM"]

COMPARISON_PAIRS = [
    ("A0_Static", "A1_AdaptiveBasis"),
    ("A1_AdaptiveBasis", "A2_AdaptiveBasisTest"),
    ("A2_AdaptiveBasisTest", "A3_FullANNASAM"),
    ("A0_Static", "A3_FullANNASAM"),
]


def load_raw_rows(path=RAW_CSV_PATH):
    rows = []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append({
                "run": int(row["run"]),
                "config": row["config"],
                "segment": int(row["segment"]),
                "n_rounds_used": int(row["n_rounds_used"]),
                "secret_length": int(row["secret_length"]),
                "security_status": row["security_status"],
            })
    return rows


def compute_per_run_metrics(rows):
    """
    Collapses the raw per-segment rows into one row per
    (config, run): segments accepted, total key, total qubits.

    Returns: {config: {"accepted": [30 values], "total_key": [...],
                        "total_qubits": [...]}}
    """
    per_run = {}   # (config, run) -> accumulator dict

    for r in rows:
        key = (r["config"], r["run"])
        if key not in per_run:
            per_run[key] = {"accepted": 0, "total_key": 0, "total_qubits": 0}
        if r["security_status"] == "ACCEPTED":
            per_run[key]["accepted"] += 1
        per_run[key]["total_key"] += r["secret_length"]
        per_run[key]["total_qubits"] += r["n_rounds_used"]

    metrics = {cfg: {"accepted": [], "total_key": [], "total_qubits": []}
               for cfg in CONFIG_ORDER}

    num_runs = max(run for _, run in per_run.keys()) + 1

    for cfg in CONFIG_ORDER:
        for run in range(num_runs):
            acc = per_run[(cfg, run)]
            metrics[cfg]["accepted"].append(acc["accepted"])
            metrics[cfg]["total_key"].append(acc["total_key"])
            metrics[cfg]["total_qubits"].append(acc["total_qubits"])

    return metrics


def mean_std_ci(values, confidence=0.95):
    """mu, sigma, and a (1-confidence) two-sided CI via the t-distribution."""
    arr = np.array(values, dtype=float)
    n = len(arr)
    mean = arr.mean()
    std = arr.std(ddof=1) if n > 1 else 0.0
    sem = std / math.sqrt(n) if n > 0 else 0.0
    t_crit = stats.t.ppf((1 + confidence) / 2, df=n - 1) if n > 1 else 0.0
    margin = t_crit * sem
    return {"mean": mean, "std": std, "n": n,
            "ci_low": mean - margin, "ci_high": mean + margin, "margin": margin}


def paired_comparison(values_a, values_b):
    """
    Paired t-test: is config B significantly different from
    config A, using the SAME 30 seeds for both?

    Special-cases zero-variance-in-the-difference situations,
    which arise twice in this study and need different
    explanations:

      1. Every paired difference is exactly 0 (e.g. A2 vs A3
         on metrics that don't depend on t_epoch) -- genuinely
         no difference to detect.
      2. Every paired difference is the SAME NON-ZERO constant
         (e.g. A0 vs A1, where A1 accepts exactly one more
         segment than A0 in all 30 runs) -- this is actually
         the STRONGEST possible form of evidence (a perfectly
         deterministic, repeatable effect), but the standard
         t-statistic formula divides by the (zero) standard
         deviation of the difference and produces an
         uninformative inf/nan rather than reflecting that
         strength. Both cases are reported explicitly rather
         than left as a raw inf/nan, which would look like a
         computation error rather than a real, understood
         result.
    """
    a = np.array(values_a, dtype=float)
    b = np.array(values_b, dtype=float)
    diff = b - a
    diff_std = np.std(diff, ddof=1) if len(diff) > 1 else 0.0

    if diff_std < 1e-9:
        constant_diff = diff.mean()
        if abs(constant_diff) < 1e-9:
            note = ("Identical in every paired run (zero variance) -- "
                     "not a computable t-statistic, but definitively no "
                     "difference on this metric.")
        else:
            note = (f"Exactly the same difference ({constant_diff:+.2f}) in "
                     f"every one of {len(diff)} paired runs -- a perfectly "
                     f"deterministic, repeatable effect. The standard "
                     f"t-statistic is undefined here (zero variance in the "
                     f"difference), but a constant nonzero effect across "
                     f"every independent trial is the strongest possible "
                     f"form of evidence, stronger than any finite p-value.")
        return {
            "mean_diff": constant_diff, "t_stat": float("nan"), "p_value": float("nan"),
            "significant_at_0.05": True if abs(constant_diff) > 1e-9 else False,
            "note": note,
        }

    t_stat, p_value = stats.ttest_rel(b, a)
    return {
        "mean_diff": diff.mean(),
        "t_stat": t_stat,
        "p_value": p_value,
        "significant_at_0.05": bool(p_value < 0.05),
        "note": "",
    }


def print_summary_table(metrics, metric_name, unit=""):
    print(f"\n{metric_name} -- mean +/- 95% CI across {metrics[CONFIG_ORDER[0]]['_n']} runs")
    print(f"{'Config':<22} | {'Mean':>10} | {'Std Dev':>10} | {'95% CI':>24}")
    print("-" * 75)
    for cfg in CONFIG_ORDER:
        stat = metrics[cfg]
        print(f"{cfg:<22} | {stat['mean']:>10.2f} | {stat['std']:>10.2f} | "
              f"[{stat['ci_low']:>9.2f}, {stat['ci_high']:>9.2f}] {unit}")


def print_comparisons(comparisons, metric_name):
    print(f"\nPaired comparisons -- {metric_name}")
    print(f"{'Comparison':<20} | {'Mean Diff':>12} | {'t-stat':>8} | {'p-value':>10} | Significant (p<0.05)?")
    print("-" * 85)
    for (a, b), result in comparisons.items():
        if result.get("note"):
            sig = "YES (deterministic)" if result["significant_at_0.05"] else "no"
            print(f"{a} vs {b:<10} | {result['mean_diff']:>12.2f} | "
                  f"{'--':>8} | {'--':>10} | {sig}")
            print(f"    -> {result['note']}")
        else:
            sig = "YES" if result["significant_at_0.05"] else "no"
            print(f"{a} vs {b:<10} | {result['mean_diff']:>12.2f} | "
                  f"{result['t_stat']:>8.3f} | {result['p_value']:>10.5f} | {sig}")


def save_processed_csv(metrics_by_name, path=os.path.join(PROCESSED_DIR, "phase7_statistics_summary.csv")):
    if not os.path.exists(os.path.dirname(path)):
        os.makedirs(os.path.dirname(path))

    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["metric", "config", "mean", "std", "n", "ci_low", "ci_high"])
        for metric_name, per_config_stats in metrics_by_name.items():
            for cfg in CONFIG_ORDER:
                s = per_config_stats[cfg]
                writer.writerow([metric_name, cfg, round(s["mean"], 4), round(s["std"], 4),
                                  s["n"], round(s["ci_low"], 4), round(s["ci_high"], 4)])

    print(f"\nSaved: {path}")


def save_comparisons_csv(comparisons_by_metric, path=os.path.join(PROCESSED_DIR, "phase7_comparisons.csv")):
    if not os.path.exists(os.path.dirname(path)):
        os.makedirs(os.path.dirname(path))

    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["metric", "config_a", "config_b", "mean_diff", "t_stat",
                          "p_value", "significant_at_0.05", "note"])
        for metric_name, comparisons in comparisons_by_metric.items():
            for (a, b), result in comparisons.items():
                writer.writerow([metric_name, a, b, round(result["mean_diff"], 4),
                                  round(result["t_stat"], 4) if not result.get("note") else "",
                                  round(result["p_value"], 6) if not result.get("note") else "",
                                  result["significant_at_0.05"], result.get("note", "")])

    print(f"Saved: {path}")


def generate_statistics_graphs(metrics_by_name):
    if not os.path.exists("graphs"):
        os.makedirs("graphs")

    colors = ["#909497", "#F5B041", "#2E86C1", "#28B463"]

    fig, axes = plt.subplots(1, 3, figsize=(16, 5))

    plot_specs = [
        ("accepted", "Segments Accepted (out of 5)", axes[0]),
        ("total_key", "Total Key Generated (bits)", axes[1]),
        ("total_qubits", "Total Qubits Transmitted", axes[2]),
    ]

    for metric_key, title, ax in plot_specs:
        stat = metrics_by_name[metric_key]
        means = [stat[cfg]["mean"] for cfg in CONFIG_ORDER]
        margins = [stat[cfg]["margin"] for cfg in CONFIG_ORDER]

        ax.bar(CONFIG_ORDER, means, yerr=margins, capsize=6, color=colors)
        ax.set_title(title)
        ax.set_ylabel("Mean value (95% CI)")
        ax.tick_params(axis='x', rotation=15)
        ax.grid(axis='y')

    plt.suptitle(f"Phase 7: Statistics Across {stat[CONFIG_ORDER[0]]['n']} Independent Runs "
                 "(mean +/- 95% CI)", fontsize=13)
    plt.tight_layout()
    plt.savefig("graphs/graph36_phase7_statistics_summary.png", dpi=150)
    plt.close()

    print("Graph saved: graphs/graph36_phase7_statistics_summary.png")


def main():
    print("=" * 90)
    print("PHASE 7: STATISTICAL ANALYSIS")
    print("=" * 90)

    if not os.path.exists(RAW_CSV_PATH):
        print(f"\nERROR: {RAW_CSV_PATH} not found. Run experiment_runner.py first.")
        return

    rows = load_raw_rows()
    print(f"\nLoaded {len(rows)} raw rows from {RAW_CSV_PATH}")

    per_run = compute_per_run_metrics(rows)

    metrics_by_name = {}
    for metric_key, metric_label, unit in [
        ("accepted", "Segments Accepted (out of 5)", "segments"),
        ("total_key", "Total Secret Key Generated", "bits"),
        ("total_qubits", "Total Qubits Transmitted", "qubits"),
    ]:
        stats_per_config = {}
        for cfg in CONFIG_ORDER:
            s = mean_std_ci(per_run[cfg][metric_key])
            s["_n"] = s["n"]
            stats_per_config[cfg] = s
        metrics_by_name[metric_key] = stats_per_config
        print_summary_table(stats_per_config, metric_label, unit)

    comparisons_by_metric = {}
    for metric_key, metric_label in [
        ("accepted", "Segments Accepted"),
        ("total_key", "Total Key Generated"),
    ]:
        comparisons = {}
        for a, b in COMPARISON_PAIRS:
            comparisons[(a, b)] = paired_comparison(per_run[a][metric_key], per_run[b][metric_key])
        comparisons_by_metric[metric_key] = comparisons
        print_comparisons(comparisons, metric_label)

    save_processed_csv(metrics_by_name)
    save_comparisons_csv(comparisons_by_metric)
    generate_statistics_graphs(metrics_by_name)

    print("\n" + "=" * 90)
    print("STATISTICAL ANALYSIS COMPLETE")
    print("=" * 90)


if __name__ == "__main__":
    main()
