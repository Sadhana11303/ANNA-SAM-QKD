"""
===========================================================
main.py

ANNA-SAM -- Phase 1 (Quantum correctness) + Phase 2 (Security)

Runs the full pipeline:
    Channel -> Entanglement -> Measurement -> Sifting
    -> Parameter Estimation -> Security Gate
    -> Privacy Amplification -> K_i

across a dynamic QBER schedule (Head-End <-> one receiver),
to validate the required Phase 2 test criterion:

    QBER up  =>  secret key length down  =>  security gate aborts

Run:
    python main.py
===========================================================
"""

import csv
import os
import random

import numpy as np
import matplotlib.pyplot as plt

import config
from quantum.channel import DynamicQBERSchedule, build_noise_model
from quantum.measurement import run_measurement_batch
from quantum.qber import qber_from_rounds

from security.parameter_estimation import phase_error_upper_bound
from security.error_correction import error_correction
from security.finite_key import calculate_secret_key_length
from security.security_gate import security_gate
from security.privacy_amplification import privacy_amplification


random.seed(config.RANDOM_SEED)
np.random.seed(config.RANDOM_SEED)


# ==========================================================
# Dynamic QBER schedule (from the guideline's worked example)
# ==========================================================

QBER_SCHEDULE = DynamicQBERSchedule([
    (50000, 0.01),   # Blocks 1-200      QBER = 1%
    (50000, 0.03),   # Blocks 201-400    QBER = 3%
    (50000, 0.06),   # Blocks 401-600    QBER = 6%
    (37500, 0.10),   # Blocks 601-750    QBER = 10%
    (37500, 0.02),   # Blocks 751-900    QBER = 2%
])
# NOTE: scaled from the guideline's illustrative (200,200,200,150,150)
# block-count example. Sifting requires BOTH parties to independently
# choose the X basis for a round to count as a test round, so with
# P_X_INITIAL = 0.10 the match probability is p_x^2 = 1% of all rounds,
# not 10%. Reaching config.N_TEST_MIN = 500 test rounds per segment
# therefore needs roughly 50,000 total rounds per segment at this p_x.
# This scarcity is not a bug -- it is precisely the shortfall that
# Phase 3's ANNA controller (adaptive n_test allocation) is designed to
# fix; a naive fixed p_x wastes the great majority of transmitted qubits.


def run_epoch(n_rounds, qber, p_z=config.P_Z_INITIAL, rng=None):
    """
    Runs one epoch of n_rounds Bell-pair rounds between the
    Head-End and a single receiver, through the full Phase 1
    (real Qiskit quantum simulation) + Phase 2 (security)
    pipeline. Returns a result dict for logging.
    """
    r = rng if rng is not None else random

    p_x = 1.0 - p_z

    # Each round, Alice and Bob each independently choose Z or X
    # with probability p_z / p_x. Rather than looping choose_basis()
    # n_rounds times, sample the joint (alice_basis, bob_basis)
    # outcome counts directly from the equivalent multinomial
    # distribution -- statistically identical, far faster.
    probs = [p_z * p_z, p_z * p_x, p_x * p_z, p_x * p_x]  # ZZ, ZX, XZ, XX
    n_zz, n_zx, n_xz, n_xx = np.random.multinomial(n_rounds, probs)

    noise_model = build_noise_model(qber)

    # Z-Z rounds become key material; X-X rounds become the test
    # sample. Z-X / X-Z (basis mismatch) are discarded regardless
    # of measurement outcome, so they are not simulated at all --
    # this is a real efficiency choice, not an approximation of
    # the physics itself.
    key_rounds = run_measurement_batch("Z", "Z", noise_model, int(n_zz), r)
    test_rounds = run_measurement_batch("X", "X", noise_model, int(n_xx), r)

    n_z = len(key_rounds)
    n_x = len(test_rounds)
    n_discarded = int(n_zx) + int(n_xz)

    q_x = qber_from_rounds(test_rounds)

    # ---- Parameter Estimation ----
    e_x_upper = phase_error_upper_bound(q_x, n_x, n_z, config.EPS_PE)

    # ---- Error Correction ----
    alice_key_z = [k[0] for k in key_rounds]
    bob_key_z = [k[1] for k in key_rounds]

    corrected_bob_key, leak_ec, e_z = error_correction(
        alice_key_z, bob_key_z, efficiency=config.EC_EFFICIENCY
    )

    # ---- Finite-Key Length ----
    secret_length = calculate_secret_key_length(
        n_z, e_x_upper, leak_ec, config.EPS_SEC_MAX, config.EPS_COR_MAX
    )

    # ---- Security Gate ----
    accepted = security_gate(
        secret_length, config.EPS_SEC_MAX, config.EPS_COR_MAX, config
    )

    # ---- Privacy Amplification (only if accepted) ----
    if accepted:
        final_key = privacy_amplification(alice_key_z, secret_length)
    else:
        final_key = ""
        secret_length = 0

    return {
        "n_rounds": n_rounds,
        "channel_qber": qber,
        "n_z": n_z,
        "n_x": n_x,
        "n_discarded": n_discarded,
        "q_x": round(q_x, 4),
        "e_z": round(e_z, 4),
        "e_x_upper": round(e_x_upper, 4),
        "leak_ec": round(leak_ec, 2),
        "secret_length": secret_length,
        "security_status": "ACCEPTED" if accepted else "ABORTED",
        "final_key_preview": final_key[:32] + ("..." if len(final_key) > 32 else ""),
        "final_key_bits": final_key,
    }


def generate_graphs(rows):
    """
    rows: list of [segment, n_rounds, channel_qber, n_z, n_x, q_x, e_z,
                    e_x_upper, leak_ec, secret_length, security_status]
    """
    if not os.path.exists("graphs"):
        os.makedirs("graphs")

    segments = [r[0] for r in rows]
    channel_qber = [r[2] * 100 for r in rows]
    q_x = [r[5] * 100 for r in rows]
    e_z = [r[6] * 100 for r in rows]
    e_x_upper = [r[7] * 100 for r in rows]
    leak_ec = [r[8] for r in rows]
    secret_length = [r[9] for r in rows]
    status = [r[10] for r in rows]
    colors = ["#28B463" if s == "ACCEPTED" else "#CB4335" for s in status]

    # ---- Graph 1: Secret Key Length vs Channel QBER (the core result) ----
    plt.figure(figsize=(7.5, 4.5))
    bars = plt.bar([f"Seg {s}\n({q:.0f}%)" for s, q in zip(segments, channel_qber)],
                    secret_length, color=colors)
    plt.title("Secret Key Length vs Channel QBER per Segment")
    plt.xlabel("Segment (Channel QBER)")
    plt.ylabel("Secret Key Length (bits)")
    for bar, val, st in zip(bars, secret_length, status):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(secret_length)*0.02,
                  f"{val}\n{st}", ha='center', fontsize=8)
    plt.grid(axis='y')
    plt.tight_layout()
    plt.savefig("graphs/graph19_secret_key_vs_qber.png", dpi=150)
    plt.close()

    # ---- Graph 2: Channel QBER vs measured Q_X and E_Z ----
    # Sort by channel QBER so the line doesn't zigzag (segments run
    # 1%,3%,6%,10%,2% in experiment order, not ascending QBER order).
    sorted_idx = sorted(range(len(channel_qber)), key=lambda i: channel_qber[i])
    sorted_qber = [channel_qber[i] for i in sorted_idx]
    sorted_qx = [q_x[i] for i in sorted_idx]
    sorted_ez = [e_z[i] for i in sorted_idx]

    plt.figure(figsize=(7.5, 4.5))
    plt.plot(sorted_qber, sorted_qber, linestyle='--', color='gray', label='Ideal (y = x)')
    plt.plot(sorted_qber, sorted_qx, marker='o', label='Measured Q_X (test basis)', color='#2E86C1')
    plt.plot(sorted_qber, sorted_ez, marker='s', label='Measured E_Z (key basis)', color='#CB4335')
    plt.title("Measured Error Rates vs Actual Channel QBER")
    plt.xlabel("Channel QBER (%)")
    plt.ylabel("Measured Error Rate (%)")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("graphs/graph20_qx_ez_vs_channel_qber.png", dpi=150)
    plt.close()

    # ---- Graph 3: Phase error upper bound vs channel QBER ----
    sorted_e_x_upper = [e_x_upper[i] for i in sorted_idx]

    plt.figure(figsize=(7.5, 4.5))
    plt.plot(sorted_qber, sorted_e_x_upper, marker='o', color='#8E44AD')
    plt.title("Finite-Key Phase Error Upper Bound (e_X^U) vs Channel QBER")
    plt.xlabel("Channel QBER (%)")
    plt.ylabel("e_X^U (%)")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("graphs/graph21_phase_error_bound.png", dpi=150)
    plt.close()

    # ---- Graph 4: EC leakage vs channel QBER ----
    plt.figure(figsize=(7.5, 4.5))
    plt.bar([f"{q:.0f}%" for q in channel_qber], leak_ec, color="#F5B041")
    plt.title("Error-Correction Leakage (leak_EC) vs Channel QBER")
    plt.xlabel("Channel QBER")
    plt.ylabel("Bits Leaked During EC")
    plt.grid(axis='y')
    plt.tight_layout()
    plt.savefig("graphs/graph22_ec_leakage.png", dpi=150)
    plt.close()

    print("\nGraphs saved: graphs/graph19..22 "
          "(secret key vs QBER, Q_X/E_Z tracking, phase-error bound, EC leakage)")


def main():
    if not os.path.exists("results/raw"):
        os.makedirs("results/raw")

    print("=" * 78)
    print("ANNA-SAM -- Phase 1 (Quantum Correctness) + Phase 2 (Security)")
    print("Dynamic-channel test: QBER up => secret key length down => abort")
    print("=" * 78)

    rows = []
    header = ["segment", "n_rounds", "channel_qber", "n_z", "n_x",
              "q_x", "e_z", "e_x_upper", "leak_ec",
              "secret_length", "security_status"]

    print(f"\n{'Seg':>3} | {'Rounds':>6} | {'Ch.QBER':>8} | {'n_Z':>5} | {'n_X':>5} | "
          f"{'Q_X':>6} | {'E_Z':>6} | {'e_X^U':>6} | {'leak_EC':>8} | "
          f"{'Secret Len':>10} | Status")
    print("-" * 100)

    for seg_idx, n_rounds, qber in QBER_SCHEDULE.iter_segments():
        result = run_epoch(n_rounds, qber)

        print(f"{seg_idx:>3} | {result['n_rounds']:>6} | {result['channel_qber']*100:>7.1f}% | "
              f"{result['n_z']:>5} | {result['n_x']:>5} | "
              f"{result['q_x']*100:>5.2f}% | {result['e_z']*100:>5.2f}% | "
              f"{result['e_x_upper']*100:>5.2f}% | {result['leak_ec']:>8.1f} | "
              f"{result['secret_length']:>10} | {result['security_status']}")

        rows.append([
            seg_idx, result["n_rounds"], result["channel_qber"],
            result["n_z"], result["n_x"], result["q_x"], result["e_z"],
            result["e_x_upper"], result["leak_ec"],
            result["secret_length"], result["security_status"],
        ])

    # ---- Save CSV ----
    csv_path = "results/raw/phase1_phase2_dynamic_channel.csv"
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)

    print(f"\nResults saved to {csv_path}")

    generate_graphs(rows)

    # ---- Verify the required test criterion ----
    aborted_segments = [r for r in rows if r[-1] == "ABORTED"]
    high_qber_segment = rows[3]  # the 10% QBER segment

    print("\n" + "=" * 78)
    if high_qber_segment[-1] == "ABORTED" or high_qber_segment[-2] < rows[0][-2]:
        print("TEST PASSED: secret key length drops (and/or the gate aborts) "
              "as QBER rises to 10%, as required.")
    else:
        print("TEST INCONCLUSIVE: inspect the table above -- with EPS_SEC_MAX "
              "this strict, high-QBER segments should show reduced or zero "
              "secret key length.")
    print("=" * 78)


if __name__ == "__main__":
    main()
