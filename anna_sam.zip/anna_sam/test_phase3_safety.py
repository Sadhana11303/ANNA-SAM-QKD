"""
===========================================================
test_phase3_safety.py

Phase 3 required test criterion:

    a_unsafe^prop -> a_safe

Feeds the safety filter a mix of safe and deliberately unsafe
proposed actions (out-of-range p_x, undersized n_test,
non-positive t_epoch, p_z+p_x != 1) and confirms:

  1. Every unsafe proposal gets corrected into a valid action.
  2. N_unsafe_executed == 0 across all trials -- i.e. an
     unsafe action is never the one that actually reaches
     the QKD engine.

Also runs the ANNAController itself across a sweep of QBER
values to sanity-check its proposed actions stay sensible.

Run:
    python test_phase3_safety.py
===========================================================
"""

import config
from anna.state import ANNAState
from anna.controller import ANNAController
from anna.action_space import validate_action, is_valid
from anna.safety_filter import safety_filter, SafetyFilterLog


def test_deliberately_unsafe_actions():
    print("=" * 78)
    print("TEST 1: Deliberately unsafe proposed actions -> safety_filter")
    print("=" * 78)

    unsafe_actions = [
        {"p_z": 0.99, "p_x": 0.01, "n_test": 100, "t_epoch": 50},   # p_x below P_X_MIN, n_test too low
        {"p_z": 0.5,  "p_x": 0.7,  "n_test": 1000, "t_epoch": 50},  # p_z + p_x != 1
        {"p_z": 0.9,  "p_x": 0.1,  "n_test": -5,  "t_epoch": 50},   # negative n_test
        {"p_z": 1.2,  "p_x": -0.2, "n_test": 1000, "t_epoch": 50},  # p_z out of [0,1]
        {"p_z": 0.9,  "p_x": 0.1,  "n_test": 1000, "t_epoch": 0},   # non-positive t_epoch
    ]

    safe_action = {"p_z": 0.9, "p_x": 0.1, "n_test": 600, "t_epoch": 100}

    log = SafetyFilterLog()

    print(f"\n{'#':>3} | {'Proposed valid?':>16} | {'Corrected action':<55} | {'Final valid?':>12}")
    print("-" * 100)

    for i, action in enumerate(unsafe_actions + [safe_action]):
        was_valid = is_valid(action)
        safe = safety_filter(action, log=log)
        now_valid = is_valid(safe)

        safe_str = (f"p_z={safe['p_z']:.3f}, p_x={safe['p_x']:.3f}, "
                    f"n_test={safe['n_test']}, t_epoch={safe['t_epoch']}")

        print(f"{i:>3} | {str(was_valid):>16} | {safe_str:<55} | {str(now_valid):>12}")

    summary = log.summary()
    print("\nSafety filter log summary:")
    for k, v in summary.items():
        print(f"  {k:>20}: {v}")

    assert summary["unsafe_executed"] == 0, "FAILED: an unsafe action reached execution!"
    assert summary["unsafe_proposed"] == len(unsafe_actions), \
        "Unexpected count of unsafe proposals detected"
    assert summary["unsafe_corrected"] == summary["unsafe_proposed"], \
        "Not every unsafe proposal was corrected"

    print("\nTEST 1 PASSED: all unsafe proposals were corrected, "
          "N_unsafe_executed = 0.")


def test_controller_sweep():
    print("\n" + "=" * 78)
    print("TEST 2: ANNAController.select_action() across a QBER sweep")
    print("=" * 78)

    controller = ANNAController()
    log = SafetyFilterLog()

    qber_values = [0.00, 0.01, 0.03, 0.05, 0.08, 0.11, 0.15]

    print(f"\n{'QBER':>6} | {'p_z':>6} | {'p_x':>6} | {'n_test':>7} | {'t_epoch':>8} | Valid?")
    print("-" * 60)

    for qber in qber_values:
        state = ANNAState(
            qber=qber,
            key_rate=0.5,
            packet_loss=0.0,
            key_buffer=config.BUFFER_MIN * 2,
            receiver_count=config.NUM_RECEIVERS,
            group_change=0,
        )

        proposed = controller.select_action(state)
        safe = safety_filter(proposed, state, log=log)

        print(f"{qber*100:>5.1f}% | {safe['p_z']:>6.3f} | {safe['p_x']:>6.3f} | "
              f"{safe['n_test']:>7} | {safe['t_epoch']:>8} | {is_valid(safe)}")

    summary = log.summary()
    print(f"\nAcross the sweep: unsafe_executed = {summary['unsafe_executed']} "
          f"(must be 0)")

    assert summary["unsafe_executed"] == 0

    print("\nTEST 2 PASSED: controller's actions were always safe "
          "(or safely corrected) across the full QBER sweep.")


if __name__ == "__main__":
    test_deliberately_unsafe_actions()
    test_controller_sweep()

    print("\n" + "=" * 78)
    print("ALL PHASE 3 TESTS PASSED")
    print("=" * 78)
