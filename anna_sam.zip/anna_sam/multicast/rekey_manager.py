"""
===========================================================
multicast/rekey_manager.py

Decides WHEN the group must be rekeyed (a fresh K_G
generated and redistributed), based on:

    T_epoch      -- has the current epoch's time budget elapsed?
    DeltaG_t     -- did group membership change (join/leave)?
    B_i < B_min  -- has any receiver's key buffer run low?
===========================================================
"""


def rekey_required(state, elapsed_time, epoch_limit):
    """
    state       : an anna.state.ANNAState (or any object with
                  .group_change and .key_buffer attributes)
    elapsed_time: time (or rounds/epochs) since the last rekey
    epoch_limit : T_epoch, the current epoch time budget
                  (typically ANNA's own chosen action value)

    Returns True if a rekey is required now.
    """
    return (
        elapsed_time >= epoch_limit
        or bool(state.group_change)
        or state.key_buffer < _buffer_min()
    )


def _buffer_min():
    import config
    return config.BUFFER_MIN


class RekeyManager:
    """
    Small stateful convenience wrapper: tracks elapsed time
    since the last rekey and exposes a single tick(state,
    epoch_limit) call that returns whether to rekey now, and
    resets its internal clock if so.
    """

    def __init__(self):
        self.elapsed_time = 0
        self.epoch_count = 0
        self.rekey_count = 0

    def tick(self, state, epoch_limit, dt=1):
        self.elapsed_time += dt
        self.epoch_count += 1

        if rekey_required(state, self.elapsed_time, epoch_limit):
            self.elapsed_time = 0
            self.rekey_count += 1
            return True

        return False
