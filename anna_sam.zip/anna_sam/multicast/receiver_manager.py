"""
===========================================================
multicast/receiver_manager.py

Maintains the multicast group:

    G = {R_1, ..., R_N}
    G_active

Each receiver record stores its individually-established
QKD key K_i (the output of the Phase 1+2 pipeline run once
between the Head-End and that receiver), which is later used
by key_distribution.py to encapsulate the shared group key.
===========================================================
"""


class ReceiverManager:
    def __init__(self):
        self._receivers = {}   # receiver_id -> {"key": bytes, "active": bool}

    def add_receiver(self, receiver_id, individual_key_bytes):
        """
        Registers a receiver with its individually-established
        QKD key K_i (bytes). Newly added receivers are active
        by default.
        """
        self._receivers[receiver_id] = {
            "key": individual_key_bytes,
            "active": True,
        }

    def remove_receiver(self, receiver_id):
        """
        Marks a receiver as inactive (leaves the multicast
        group). Its key record is kept (not deleted) so a
        re-join doesn't require re-running QKD, but it will no
        longer receive group-key distributions while inactive.
        """
        if receiver_id in self._receivers:
            self._receivers[receiver_id]["active"] = False

    def rejoin_receiver(self, receiver_id):
        if receiver_id in self._receivers:
            self._receivers[receiver_id]["active"] = True

    def get_active_receivers(self):
        """
        Returns {receiver_id: individual_key_bytes} for every
        currently active receiver.
        """
        return {
            rid: rec["key"]
            for rid, rec in self._receivers.items()
            if rec["active"]
        }

    def get_all_receivers(self):
        return dict(self._receivers)

    def active_count(self):
        return len(self.get_active_receivers())

    def total_count(self):
        return len(self._receivers)
