"""
===========================================================
multicast/group_key.py

Generates the shared multicast group key for one epoch:

    K_G^(e) <- {0,1}^l_G

This is a FRESH, independently random key each epoch -- it
is NOT derived from the receivers' individual keys (e.g. NOT
K1 XOR K2 XOR ... XOR KN, which the guideline explicitly
warns against, since that construction leaks structure and
ties every receiver's security to every other receiver's).
The individual keys K_i are used only as the SECURE CHANNEL
(via AEAD, see key_distribution.py) to deliver this
independent group key to each receiver.
===========================================================
"""

import secrets


def generate_group_key(length_bytes=32):
    """
    length_bytes: length of the group key in bytes
                  (32 bytes = 256 bits, suitable for AES-256
                  encryption of the actual video/content stream)
    """
    return secrets.token_bytes(length_bytes)
