"""
===========================================================
multicast/key_distribution.py

Delivers the group key to every active receiver, individually
encrypted under that receiver's own QKD-derived key K_i:

    C_i = AEAD_{K_i}(K_G^(e) || ID_G || e)

Uses AES-256-GCM as the concrete AEAD construction. Since the
QKD-derived K_i can be an arbitrary bit length (the finite-key
secret length varies with channel conditions), it is first
reduced to a fixed 256-bit AES key via SHA-256 -- a standard,
deterministic key-derivation step.
===========================================================
"""

import hashlib
import secrets

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def _derive_aes_key(individual_key_bytes):
    """K_i (arbitrary length) -> 256-bit AES key."""
    return hashlib.sha256(individual_key_bytes).digest()


def encapsulate_group_key(individual_key_bytes, group_key_bytes, group_id, epoch):
    """
    Encrypts (group_key || group_id || epoch) under a key
    derived from the receiver's individual QKD key.

    Returns C_i = nonce || ciphertext (bytes), self-contained
    and ready to transmit to that receiver.
    """
    aes_key = _derive_aes_key(individual_key_bytes)
    aesgcm = AESGCM(aes_key)
    nonce = secrets.token_bytes(12)

    group_id_bytes = group_id.encode("utf-8")
    group_id_len = len(group_id_bytes).to_bytes(1, "big")
    epoch_bytes = int(epoch).to_bytes(4, "big")

    plaintext = group_id_len + group_id_bytes + epoch_bytes + group_key_bytes

    ciphertext = aesgcm.encrypt(nonce, plaintext, associated_data=None)

    return nonce + ciphertext


def decapsulate_group_key(individual_key_bytes, ciphertext_blob):
    """
    Reverses encapsulate_group_key(). Returns
    (group_key_bytes, group_id, epoch), or raises
    cryptography.exceptions.InvalidTag if K_i is wrong or the
    ciphertext was tampered with (this IS the point of AEAD --
    it authenticates as well as encrypts).
    """
    aes_key = _derive_aes_key(individual_key_bytes)
    aesgcm = AESGCM(aes_key)

    nonce = ciphertext_blob[:12]
    ciphertext = ciphertext_blob[12:]

    plaintext = aesgcm.decrypt(nonce, ciphertext, associated_data=None)

    group_id_len = plaintext[0]
    group_id = plaintext[1:1 + group_id_len].decode("utf-8")
    epoch = int.from_bytes(plaintext[1 + group_id_len:5 + group_id_len], "big")
    group_key_bytes = plaintext[5 + group_id_len:]

    return group_key_bytes, group_id, epoch


def distribute_group_key(receiver_keys, group_key_bytes, group_id, epoch):
    """
    receiver_keys: {receiver_id: individual_key_bytes} for every
                   ACTIVE receiver (e.g. from
                   ReceiverManager.get_active_receivers())

    Returns {receiver_id: ciphertext_blob} -- what actually gets
    transmitted to each receiver over the (untrusted) network.
    """
    return {
        rid: encapsulate_group_key(k_i, group_key_bytes, group_id, epoch)
        for rid, k_i in receiver_keys.items()
    }
