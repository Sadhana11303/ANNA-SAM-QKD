"""
===========================================================
video/encryption.py

Encrypts each video frame under the current multicast group
key:

    C_V = AEAD_{K_G^(e)}(V_t)

Uses AES-256-GCM (same AEAD primitive as key_distribution.py).

NONCE HANDLING: AES-GCM requires a unique nonce per message
under a fixed key -- reusing a nonce catastrophically breaks
GCM's security. Since many frames are encrypted under the
SAME group key within one epoch, each frame's nonce is built
from a random 8-byte per-epoch prefix (generated once when
the epoch's group key is established) concatenated with the
4-byte frame index. This guarantees every frame gets a
distinct nonce under a given key, without needing a fresh
random nonce generated (and distributed) per frame.

Measures T_enc and T_dec per frame.
===========================================================
"""

import secrets
import time

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def generate_nonce_prefix():
    """Fresh 8-byte nonce prefix, generated once per group-key epoch."""
    return secrets.token_bytes(8)


def _build_nonce(nonce_prefix, frame_index):
    return nonce_prefix + frame_index.to_bytes(4, "big")


def encrypt_frame(group_key_bytes, nonce_prefix, frame_index, frame_bytes):
    """
    Returns (ciphertext_bytes, t_enc_seconds).
    """
    aesgcm = AESGCM(group_key_bytes)
    nonce = _build_nonce(nonce_prefix, frame_index)

    start = time.perf_counter()
    ciphertext = aesgcm.encrypt(nonce, frame_bytes, associated_data=None)
    t_enc = time.perf_counter() - start

    return ciphertext, t_enc


def decrypt_frame(group_key_bytes, nonce_prefix, frame_index, ciphertext):
    """
    Returns (plaintext_bytes_or_None, t_dec_seconds, success_bool).
    success is False if the ciphertext was tampered with or the
    wrong key/nonce was used (AEAD authentication failure) --
    this is a genuine pipeline failure, not a simulated one.
    """
    aesgcm = AESGCM(group_key_bytes)
    nonce = _build_nonce(nonce_prefix, frame_index)

    start = time.perf_counter()
    try:
        plaintext = aesgcm.decrypt(nonce, ciphertext, associated_data=None)
        t_dec = time.perf_counter() - start
        return plaintext, t_dec, True
    except InvalidTag:
        t_dec = time.perf_counter() - start
        return None, t_dec, False
