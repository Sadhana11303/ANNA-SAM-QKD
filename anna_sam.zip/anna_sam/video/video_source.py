"""
===========================================================
video/video_source.py

Generates a synthetic video stream V_1, V_2, ..., V_T as a
sequence of fixed-size frames, standing in for an actual
encoded video feed. Each "frame" behaves like a real RTP/UDP
video packet for pipeline-testing purposes: a 4-byte frame
index header followed by pseudo-video payload bytes.

Swap generate_synthetic_stream() for a real video trace
loader later without changing encryption.py or
qos_metrics.py -- they only depend on the (index, bytes)
frame shape.
===========================================================
"""

import random


def generate_synthetic_stream(num_frames, frame_size_bytes=1400, seed=None):
    """
    Returns a list of `num_frames` frame byte-strings, each
    frame_size_bytes long (a typical MTU-sized video/RTP
    packet payload).
    """
    rng = random.Random(seed)
    frames = []

    for t in range(num_frames):
        header = t.to_bytes(4, "big")
        payload = bytes(rng.getrandbits(8) for _ in range(frame_size_bytes - 4))
        frames.append(header + payload)

    return frames


class VideoStream:
    """
    Small convenience wrapper bundling the frame list with its
    playback parameters (fps, frame size) -- QoS metrics need
    these to convert frame counts into elapsed playback time.
    """

    def __init__(self, num_frames, frame_size_bytes=1400, fps=30, seed=None):
        self.frames = generate_synthetic_stream(num_frames, frame_size_bytes, seed)
        self.frame_size_bytes = frame_size_bytes
        self.fps = fps

    def __len__(self):
        return len(self.frames)

    def duration_seconds(self):
        return len(self.frames) / self.fps

    def total_bytes(self):
        return len(self.frames) * self.frame_size_bytes
