"""
===========================================================
video/qos_metrics.py

Calculates:
    PLR          -- packet loss ratio
    Throughput   -- delivered bytes / elapsed time (all
                     delivered packets, regardless of whether
                     they later decrypted successfully)
    Goodput      -- USEFUL bytes / elapsed time (only frames
                     that were both delivered AND decrypted
                     successfully)
    T_interrupt  -- total simulated playback stall duration
    N_interrupt  -- number of distinct stall events

IMPORTANT (per the project guideline): key-buffer underflow
(from the QKD layer, anna.state.ANNAState.key_buffer) is
NEVER used here to define an interruption. A video
interruption is determined ONLY from the actual per-frame
outcomes of THIS pipeline -- whether a frame was delivered
over the (simulated, lossy) network and whether it decrypted
successfully. The QKD key buffer only affects whether a
FUTURE group-key rotation can happen safely; it says nothing
about whether the CURRENT frame, encrypted under the
already-established current group key, arrives and decrypts
correctly.
===========================================================
"""


def calculate_qos_metrics(frame_results, fps, playout_buffer_frames=5):
    """
    frame_results: ordered list of dicts, one per frame, each with:
        {
            "delivered": bool,      -- did the packet arrive over
                                       the (simulated lossy) network?
            "decrypted_ok": bool,    -- did AEAD decryption succeed?
                                       (False for frames that were
                                       never delivered)
            "bytes": int,            -- frame size in bytes
        }
    fps: playback frame rate, used to convert frame counts into
         elapsed/stall time.
    playout_buffer_frames: how many CONSECUTIVE bad frames the
         receiver's playout buffer can absorb before playback
         actually stalls (a real player buffers a little ahead,
         so a single dropped frame doesn't necessarily interrupt
         playback -- only a longer consecutive run does).

    Returns a dict of the computed metrics.
    """
    total_frames = len(frame_results)
    if total_frames == 0:
        return {
            "total_frames": 0, "lost_frames": 0, "plr": 0.0,
            "throughput_bytes_per_sec": 0.0, "goodput_bytes_per_sec": 0.0,
            "t_interrupt_sec": 0.0, "n_interrupt": 0,
        }

    frame_duration = 1.0 / fps
    elapsed_time = total_frames * frame_duration

    lost_frames = sum(1 for f in frame_results if not f["delivered"])
    plr = lost_frames / total_frames

    delivered_bytes = sum(f["bytes"] for f in frame_results if f["delivered"])
    good_bytes = sum(
        f["bytes"] for f in frame_results
        if f["delivered"] and f["decrypted_ok"]
    )

    throughput = delivered_bytes / elapsed_time if elapsed_time > 0 else 0.0
    goodput = good_bytes / elapsed_time if elapsed_time > 0 else 0.0

    # ---- Interruption detection ----
    # A "bad" frame is one that either never arrived or failed to
    # decrypt. Playback only actually stalls once BAD frames run
    # consecutively for longer than the playout buffer can absorb.
    t_interrupt = 0.0
    n_interrupt = 0
    consecutive_bad = 0
    currently_interrupted = False

    for f in frame_results:
        is_bad = (not f["delivered"]) or (not f["decrypted_ok"])

        if is_bad:
            consecutive_bad += 1
            if consecutive_bad > playout_buffer_frames:
                if not currently_interrupted:
                    n_interrupt += 1
                    currently_interrupted = True
                t_interrupt += frame_duration
        else:
            consecutive_bad = 0
            currently_interrupted = False

    return {
        "total_frames": total_frames,
        "lost_frames": lost_frames,
        "plr": plr,
        "throughput_bytes_per_sec": throughput,
        "goodput_bytes_per_sec": goodput,
        "t_interrupt_sec": t_interrupt,
        "n_interrupt": n_interrupt,
    }
