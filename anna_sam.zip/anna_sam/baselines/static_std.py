"""
===========================================================
baselines/static_std.py

A0: Static Std -- the fair fixed-configuration baseline.
No adaptation in any dimension.
===========================================================
"""

import config
from anna.controller import ANNAController

STATIC_ACTION = {
    "p_z": config.P_Z_INITIAL,
    "p_x": config.P_X_INITIAL,
    "n_test": config.STATIC_N_TEST,
    "t_epoch": config.STATIC_T_EPOCH,
}


def make_controller():
    return ANNAController(adapt_basis=False, adapt_test=False, adapt_rekey=False)
