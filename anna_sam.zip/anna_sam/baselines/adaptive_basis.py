"""
===========================================================
baselines/adaptive_basis.py

A1: Adaptive Basis -- only p_z/p_x adapt to observed QBER.
n_test and t_epoch stay fixed at the static baseline values.
===========================================================
"""

from anna.controller import ANNAController


def make_controller():
    return ANNAController(adapt_basis=True, adapt_test=False, adapt_rekey=False)
