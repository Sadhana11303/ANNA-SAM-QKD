"""
===========================================================
baselines/adaptive_resource.py

A2: Adaptive Basis + Adaptive Test Allocation.
t_epoch stays fixed at the static baseline value; only rekey
timing is not yet adaptive (that's what distinguishes A2 from
the full A3 ANNA-SAM controller).
===========================================================
"""

from anna.controller import ANNAController


def make_controller():
    return ANNAController(adapt_basis=True, adapt_test=True, adapt_rekey=False)
