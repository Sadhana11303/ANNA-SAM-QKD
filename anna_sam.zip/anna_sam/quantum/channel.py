"""
===========================================================
quantum/channel.py

Models the quantum channel using a REAL Qiskit noise model
(qiskit_aer.noise), applied to the receiver's half (qubit 1)
of each Bell pair. A Pauli bit-flip error is attached to an
identity ("id") gate inserted on qubit 1, so the noisy
channel is executed by the Aer simulator itself, not
approximated in classical Python.

DynamicQBERSchedule lets QBER(t) vary across an experiment,
e.g.:

    Blocks 1-200      QBER = 1%
    Blocks 201-400    QBER = 3%
    Blocks 401-600    QBER = 6%
    Blocks 601-750    QBER = 10%
    Blocks 751-900    QBER = 2%
===========================================================
"""

from qiskit_aer.noise import NoiseModel, depolarizing_error


def build_noise_model(qber):
    """
    Returns a Qiskit NoiseModel implementing a DEPOLARIZING
    channel on qubit 1 (the receiver's half of the pair),
    calibrated so the resulting Z-basis error rate (E_Z)
    matches the requested `qber` target.

    IMPORTANT: a depolarizing channel is used rather than a
    pure bit-flip (X-only) channel because a pure bit-flip
    error is a Z-basis-only effect -- it is provably
    invisible to X-basis measurements (X errors commute with
    the X eigenbasis), which would make the X-basis test
    sample (Q_X) read ~0% regardless of actual channel noise.
    That defeats the purpose of parameter estimation, since
    real channel noise or an eavesdropper's intercept-resend
    attack disturbs BOTH conjugate bases. A depolarizing
    channel affects Z and X measurements symmetrically, so
    Q_X correctly tracks the true disturbance level, exactly
    as required by the finite-key security proof.

    Calibration: qiskit's 1-qubit depolarizing_error(p)
    produces a Z-basis (and X-basis) flip probability of
    approximately p/2, so p = 2 * qber targets the requested
    per-basis error rate.
    """
    noise_model = NoiseModel()
    p = min(2 * qber, 1.0)
    error = depolarizing_error(p, 1)
    noise_model.add_quantum_error(error, ["id"], [1])
    return noise_model


class DynamicQBERSchedule:
    """
    Wraps a list of (num_rounds, qber) segments.
    """

    def __init__(self, segments):
        self.segments = segments

    def total_rounds(self):
        return sum(n for n, _ in self.segments)

    def iter_segments(self):
        """
        Yields (segment_index, num_rounds, qber) for each
        segment in order. Callers build the Qiskit noise
        model themselves via build_noise_model(qber).
        """
        for idx, (n_rounds, qber) in enumerate(self.segments):
            yield idx, n_rounds, qber
