"""
===========================================================
quantum/measurement.py

Basis selection (classical choice, made independently by
each party) and measurement, executed as REAL Qiskit
circuits on the Aer simulator.

Each party independently chooses B in {Z, X} according to
P(Z) = p_z, P(X) = p_x = 1 - p_z. Measuring in the X basis
is implemented by applying an H gate before the (always
computational-basis) measurement -- the standard technique
for basis rotation on real quantum hardware/simulators.

PERFORMANCE NOTE:
Rather than building and executing one circuit per round
(which would be extremely slow at N ~ 10^4-10^5 rounds),
rounds are grouped by their (alice_basis, bob_basis)
combination -- there are only 4 possible combinations per
noise level -- and each group is executed as ONE circuit
with `shots` equal to that group's round count. This is
still exact, real Qiskit/Aer simulation; it is simply
batched for tractable runtime, the same way a real
experimentalist would batch identical measurement settings.
===========================================================
"""

import random

from qiskit_aer import AerSimulator

from quantum.entanglement import build_bell_pair_circuit


def choose_basis(p_z, rng=None):
    r = rng if rng is not None else random
    if r.random() < p_z:
        return "Z"
    return "X"


def build_measurement_circuit(alice_basis, bob_basis):
    """
    Builds the full circuit: Bell-pair prep -> noise-target
    'id' gate on qubit 1 -> basis rotation (H if X) on each
    qubit -> measurement.
    """
    qc = build_bell_pair_circuit()
    qc.id(1)  # channel.py's noise model attaches its error here

    if alice_basis == "X":
        qc.h(0)
    if bob_basis == "X":
        qc.h(1)

    qc.measure(0, 0)  # qubit 0 (Head-End) -> classical bit 0
    qc.measure(1, 1)  # qubit 1 (receiver) -> classical bit 1

    return qc


def run_measurement_batch(alice_basis, bob_basis, noise_model, shots, rng=None):
    """
    Executes `shots` real, independent repetitions of the
    (alice_basis, bob_basis) measurement setting under the
    given noise model, and returns a list of
    (alice_bit, bob_bit) tuples -- one per shot.
    """
    if shots <= 0:
        return []

    qc = build_measurement_circuit(alice_basis, bob_basis)
    sim = AerSimulator(noise_model=noise_model)

    seed = None
    if rng is not None:
        seed = rng.randint(0, 2 ** 31 - 1)

    result = sim.run(qc, shots=shots, seed_simulator=seed).result()
    counts = result.get_counts()

    outcomes = []
    for bitstring, count in counts.items():
        # Qiskit bitstring format is 'c1 c0' -> rightmost char
        # is classical bit 0 (Head-End/qubit 0), the character
        # before it is classical bit 1 (receiver/qubit 1).
        alice_bit = int(bitstring[-1])
        bob_bit = int(bitstring[-2])
        outcomes.extend([(alice_bit, bob_bit)] * count)

    return outcomes
