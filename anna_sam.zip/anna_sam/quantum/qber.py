"""
===========================================================
quantum/qber.py

QBER calculation. Test-basis QBER (Q_X) and key-basis error
rate (E_Z) are kept SEPARATE -- Q_X is used for security
estimation (parameter estimation), E_Z would only ever be
computed for offline diagnostics/validation, never revealed
as part of the live protocol (revealing key-basis bits
would leak the key itself).
===========================================================
"""


def calculate_qber(alice_bits, bob_bits):
    """
    alice_bits, bob_bits: equal-length lists of 0/1
    Returns the fraction of mismatched bits.
    """
    if len(alice_bits) == 0:
        return 0.0

    errors = sum(a != b for a, b in zip(alice_bits, bob_bits))
    return errors / len(alice_bits)


def qber_from_rounds(rounds):
    """
    rounds: list of (alice_bit, bob_bit) tuples, e.g. the
    output of sift_rounds()'s test_rounds or key_rounds.
    """
    if not rounds:
        return 0.0

    alice_bits = [r[0] for r in rounds]
    bob_bits = [r[1] for r in rounds]

    return calculate_qber(alice_bits, bob_bits)
