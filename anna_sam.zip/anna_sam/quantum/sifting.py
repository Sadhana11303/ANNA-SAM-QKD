"""
===========================================================
quantum/sifting.py

After measurement, Head-End and receiver reveal their bases
over the authenticated classical channel. Z-Z matches
become the raw key material (X_Z); X-X matches become the
parameter-estimation sample (X_X). All other combinations
(Z-X, X-Z) are discarded.
===========================================================
"""


def sift_rounds(alice_basis_list, bob_basis_list,
                 alice_bits_list, bob_bits_list):

    key_rounds = []    # (alice_bit, bob_bit) where both used Z
    test_rounds = []   # (alice_bit, bob_bit) where both used X

    for a_basis, b_basis, a_bit, b_bit in zip(
            alice_basis_list, bob_basis_list,
            alice_bits_list, bob_bits_list):

        if a_basis == "Z" and b_basis == "Z":
            key_rounds.append((a_bit, b_bit))
        elif a_basis == "X" and b_basis == "X":
            test_rounds.append((a_bit, b_bit))
        # else: basis mismatch, discarded

    return key_rounds, test_rounds
