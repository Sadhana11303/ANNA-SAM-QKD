"""
===========================================================
quantum/entanglement.py

Generates the quantum resource using REAL Qiskit circuits:
|Phi+>_{H,Ri} = (|00> + |11>) / sqrt(2), built from an H
gate on qubit 0 (Head-End) followed by a CX(0,1) into
qubit 1 (receiver).
===========================================================
"""

from qiskit import QuantumCircuit


def build_bell_pair_circuit():
    """
    Returns a 2-qubit, 2-classical-bit QuantumCircuit
    prepared in the |Phi+> state, with no measurements yet.
    Qubit 0 = Head-End's half, Qubit 1 = receiver's half.
    """
    qc = QuantumCircuit(2, 2, name="BellPair_PhiPlus")
    qc.h(0)
    qc.cx(0, 1)
    return qc
