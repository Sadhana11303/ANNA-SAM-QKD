"""
===========================================================
experiments/security_test.py

Runs the full BB84 + finite-key security pipeline under a
real intercept-resend eavesdropper (attacks/intercept_resend.py),
sweeping the interception probability from 0% to 100%, at a
near-zero background channel noise level so the attack's own
effect can be seen cleanly.

Validates against the well-known literature result: full
interception (eve_intercept_prob = 1.0) on an ideal channel
converges to a 25% QBER.

Run:
    python experiments/security_test.py
===========================================================
"""

import os
import random
import sys

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import config
from quantum.channel import build_noise_model
from quantum.qber import qber_from_rounds

from security.parameter_estimation import phase_error_upper_bound
from security.error_correction import error_correction
from security.finite_key import calculate_secret_key_length
from security.security_gate import security_gate

from attacks.intercept_resend import run_intercept_resend_batch


N_ROUNDS = 60000
BACKGROUND_NOISE = 0.005   # near-zero, isolates the attack's own effect
P_Z = config.P_Z_INITIAL


def run_epoch_under_attack(n_rounds, eve_intercept_prob, rng):
    p_x = 1.0 - P_Z
    probs = [P_Z * P_Z, P_Z * p_x, p_x * P_Z, p_x * p_x]
    n_zz, n_zx, n_xz, n_xx = np.random.multinomial(n_rounds, probs)

    noise_model = build_noise_model(BACKGROUND_NOISE)

    key_rounds = run_intercept_resend_batch(
        "Z", noise_model, int(n_zz), eve_intercept_prob, rng
    )
    test_rounds = run_intercept_resend_batch(
        "X", noise_model, int(n_xx), eve_intercept_prob, rng
    )

    n_z = len(key_rounds)
    n_x = len(test_rounds)

    q_x = qber_from_rounds(test_rounds)
    e_x_upper = phase_error_upper_bound(q_x, n_x, n_z, config.EPS_PE)

    alice_key_z = [k[0] for k in key_rounds]
    bob_key_z = [k[1] for k in key_rounds]

    _, leak_ec, e_z = error_correction(alice_key_z, bob_key_z, config.EC_EFFICIENCY)

    secret_length = calculate_secret_key_length(
        n_z, e_x_upper, leak_ec, config.EPS_SEC_MAX, config.EPS_COR_MAX
    )
    accepted = security_gate(secret_length, config.EPS_SEC_MAX, config.EPS_COR_MAX, config)
    if not accepted:
        secret_length = 0

    return {
        "n_z": n_z, "n_x": n_x, "q_x": q_x, "e_z": e_z,
        "e_x_upper": e_x_upper, "secret_length": secret_length,
        "security_status": "ACCEPTED" if accepted else "ABORTED",
    }


def main():
    random.seed(config.RANDOM_SEED)
    np.random.seed(config.RANDOM_SEED)
    rng = random.Random(config.RANDOM_SEED)

    print("=" * 90)
    print("PHASE 6: SECURITY TEST -- Intercept-Resend Attack Detection")
    print(f"(background channel noise = {BACKGROUND_NOISE*100:.1f}%, isolating the attack's own effect)")
    print("=" * 90)

    intercept_levels = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7, 1.0]
    rows = []

    print(f"\n{'P(intercept)':>13} | {'Q_X':>7} | {'E_Z':>7} | {'e_X^U':>7} | "
          f"{'Secret Len':>10} | Status")
    print("-" * 70)

    for p in intercept_levels:
        result = run_epoch_under_attack(N_ROUNDS, p, rng)
        rows.append((p, result))

        print(f"{p:>13.2f} | {result['q_x']*100:>6.2f}% | {result['e_z']*100:>6.2f}% | "
              f"{result['e_x_upper']*100:>6.2f}% | {result['secret_length']:>10} | "
              f"{result['security_status']}")

    # ---- Validate against literature: full interception -> ~25% QBER ----
    full_intercept_result = rows[-1][1]
    print(f"\nValidation: at 100% interception with near-zero background noise, "
          f"measured Q_X = {full_intercept_result['q_x']*100:.2f}% "
          f"(literature reference: ~25%)")
    assert 0.20 <= full_intercept_result["q_x"] <= 0.30, \
        "Measured QBER under full interception is outside the expected ~25% range"
    print("VALIDATED: matches the theoretical intercept-resend QBER derivation.")

    # ---- Find the detection threshold: smallest p where the gate aborts ----
    first_abort_p = None
    for p, result in rows:
        if result["security_status"] == "ABORTED":
            first_abort_p = p
            break

    print(f"\nSecurity gate first aborts at interception probability >= "
          f"{first_abort_p if first_abort_p is not None else 'never (within tested range)'}")

    generate_graphs(rows)

    print("\n" + "=" * 90)
    print("SECURITY TEST COMPLETE -- eavesdropping correctly detected and rejected")
    print("=" * 90)


def generate_graphs(rows):
    if not os.path.exists("graphs"):
        os.makedirs("graphs")

    p_values = [p for p, _ in rows]
    q_x_values = [r["q_x"] * 100 for _, r in rows]
    secret_lengths = [r["secret_length"] for _, r in rows]
    statuses = [r["security_status"] for _, r in rows]
    colors = ["#28B463" if s == "ACCEPTED" else "#CB4335" for s in statuses]

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    axes[0].plot(p_values, q_x_values, marker='o', color="#2E86C1")
    axes[0].axhline(y=25, color='gray', linestyle='--', label='Literature reference (25%)')
    axes[0].axhline(y=config.QBER_MAX * 100, color='red', linestyle=':',
                     label=f'Security threshold ({config.QBER_MAX*100:.0f}%)')
    axes[0].set_xlabel("Eve's Interception Probability")
    axes[0].set_ylabel("Measured Q_X (%)")
    axes[0].set_title("QBER vs Interception Probability")
    axes[0].legend()
    axes[0].grid(True)

    axes[1].bar([f"{p:.1f}" for p in p_values], secret_lengths, color=colors)
    axes[1].set_xlabel("Eve's Interception Probability")
    axes[1].set_ylabel("Secret Key Length (bits)")
    axes[1].set_title("Secret Key Length vs Interception Probability")
    axes[1].grid(axis='y')

    plt.tight_layout()
    plt.savefig("graphs/graph32_security_test_intercept_resend.png", dpi=150)
    plt.close()

    print("\nGraph saved: graphs/graph32_security_test_intercept_resend.png")


if __name__ == "__main__":
    main()
