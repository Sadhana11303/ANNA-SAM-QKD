"""
===========================================================
experiments/dynamic_channel_comparison.py

The core Phase 3 payoff experiment: runs the SAME dynamic
QBER schedule used in main.py through two strategies:

  STATIC   -- fixed p_z = config.P_Z_INITIAL every epoch
              (exactly what main.py already does)
  ADAPTIVE -- ANNAController proposes [p_z, p_x, n_test,
              t_epoch] each epoch, safety_filter clamps it
              into range, then that epoch runs with the
              controller's chosen p_z.

IMPORTANT: this is a genuine ONLINE control loop, not a
lookup table. ANNA does NOT know the upcoming segment's true
QBER in advance -- it only observes the *previous* epoch's
measured Q_X, key rate, and key buffer, and reacts to that,
exactly as a real deployed controller would have to.

For a fair comparison, both strategies are given the SAME
total qubit budget (n_rounds) per segment -- the question
being tested is "given the same resources, does adapting
p_z/p_x do better than a fixed split?", not "does ANNA get
to use more qubits".

Run:
    python experiments/dynamic_channel_comparison.py
===========================================================
"""

import csv
import os
import random
import sys

import numpy as np
import matplotlib.pyplot as plt

# Allow running this file directly (python experiments/dynamic_channel_comparison.py)
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import config
from main import run_epoch, QBER_SCHEDULE

from anna.state import ANNAState
from anna.controller import ANNAController
from anna.safety_filter import safety_filter, SafetyFilterLog


def run_static_baseline(schedule, rng):
    """
    Fixed p_z = config.P_Z_INITIAL every epoch, no adaptation.
    """
    rows = []
    key_buffer = 0.0

    for seg_idx, n_rounds, true_qber in schedule.iter_segments():
        result = run_epoch(n_rounds, true_qber, p_z=config.P_Z_INITIAL, rng=rng)
        key_buffer += result["secret_length"]

        rows.append({
            "segment": seg_idx,
            "n_rounds": n_rounds,
            "true_qber": true_qber,
            "p_z": config.P_Z_INITIAL,
            "p_x": 1 - config.P_Z_INITIAL,
            "n_x": result["n_x"],
            "n_z": result["n_z"],
            "q_x": result["q_x"],
            "e_x_upper": result["e_x_upper"],
            "secret_length": result["secret_length"],
            "security_status": result["security_status"],
            "cumulative_key_buffer": key_buffer,
        })

    return rows


def run_anna_adaptive(schedule, rng):
    """
    ANNA proposes an action each epoch based on the state
    OBSERVED FROM THE PREVIOUS EPOCH ONLY -- it has no
    foreknowledge of the upcoming segment's true QBER.
    """
    controller = ANNAController()
    log = SafetyFilterLog()

    # Initial state before any observation: assume a calm channel
    # (the controller has no information yet, so it starts from
    # the same conservative defaults a static system would use).
    state = ANNAState(
        qber=0.0,
        key_rate=0.0,
        packet_loss=0.0,
        key_buffer=0.0,
        receiver_count=config.NUM_RECEIVERS,
        group_change=0,
    )

    rows = []
    key_buffer = 0.0

    for seg_idx, n_rounds, true_qber in schedule.iter_segments():
        proposed = controller.select_action(state)
        safe_action = safety_filter(proposed, state, log=log)

        result = run_epoch(n_rounds, true_qber, p_z=safe_action["p_z"], rng=rng)

        key_buffer += result["secret_length"]
        key_rate = result["secret_length"] / n_rounds if n_rounds > 0 else 0.0

        rows.append({
            "segment": seg_idx,
            "n_rounds": n_rounds,
            "true_qber": true_qber,
            "p_z": safe_action["p_z"],
            "p_x": safe_action["p_x"],
            "requested_n_test": safe_action["n_test"],
            "t_epoch": safe_action["t_epoch"],
            "n_x": result["n_x"],
            "n_z": result["n_z"],
            "q_x": result["q_x"],
            "e_x_upper": result["e_x_upper"],
            "secret_length": result["secret_length"],
            "security_status": result["security_status"],
            "cumulative_key_buffer": key_buffer,
        })

        # Update state from what was actually OBSERVED this epoch,
        # for the controller to react to next epoch.
        state = ANNAState(
            qber=result["q_x"],
            key_rate=key_rate,
            packet_loss=0.0,
            key_buffer=key_buffer,
            receiver_count=config.NUM_RECEIVERS,
            group_change=0,
        )

    return rows, log


def print_comparison_table(static_rows, anna_rows):
    print(f"\n{'Seg':>3} | {'True QBER':>9} | "
          f"{'Static p_z':>10} | {'Static Key':>10} | {'Static':>10} | "
          f"{'ANNA p_z':>9} | {'ANNA Key':>9} | {'ANNA':>10}")
    print("-" * 100)

    for s, a in zip(static_rows, anna_rows):
        print(f"{s['segment']:>3} | {s['true_qber']*100:>8.1f}% | "
              f"{s['p_z']:>10.3f} | {s['secret_length']:>10} | {s['security_status']:>10} | "
              f"{a['p_z']:>9.3f} | {a['secret_length']:>9} | {a['security_status']:>10}")


def save_csv(rows, filename, extra_fields):
    path = os.path.join("results", "raw", filename)
    if not os.path.exists(os.path.dirname(path)):
        os.makedirs(os.path.dirname(path))

    fieldnames = ["segment", "n_rounds", "true_qber", "p_z", "p_x"] + extra_fields + \
                 ["n_x", "n_z", "q_x", "e_x_upper", "secret_length",
                  "security_status", "cumulative_key_buffer"]

    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})

    print(f"Saved: {path}")


def generate_comparison_graphs(static_rows, anna_rows):
    if not os.path.exists("graphs"):
        os.makedirs("graphs")

    segments = [r["segment"] for r in static_rows]
    true_qber = [r["true_qber"] * 100 for r in static_rows]

    static_key = [r["secret_length"] for r in static_rows]
    anna_key = [r["secret_length"] for r in anna_rows]

    static_status = [r["security_status"] for r in static_rows]
    anna_status = [r["security_status"] for r in anna_rows]

    static_buffer = [r["cumulative_key_buffer"] for r in static_rows]
    anna_buffer = [r["cumulative_key_buffer"] for r in anna_rows]

    static_px = [r["p_x"] for r in static_rows]
    anna_px = [r["p_x"] for r in anna_rows]

    labels = [f"Seg {s}\n({q:.0f}%)" for s, q in zip(segments, true_qber)]
    x = np.arange(len(segments))
    width = 0.35

    # ---- Graph 23: Secret key length, static vs ANNA, side by side ----
    plt.figure(figsize=(9, 5))
    bars1 = plt.bar(x - width/2, static_key, width, label="Static (fixed p_z)", color="#909497")
    bars2 = plt.bar(x + width/2, anna_key, width, label="ANNA-Adaptive", color="#28B463")
    for bar, st in zip(bars1, static_status):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height(), st,
                  ha='center', va='bottom', fontsize=7, rotation=90)
    for bar, st in zip(bars2, anna_status):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height(), st,
                  ha='center', va='bottom', fontsize=7, rotation=90)
    plt.xticks(x, labels)
    plt.title("Secret Key Length per Segment: Static Baseline vs ANNA-Adaptive")
    plt.ylabel("Secret Key Length (bits)")
    plt.legend()
    plt.grid(axis='y')
    plt.tight_layout()
    plt.savefig("graphs/graph23_static_vs_anna_key_length.png", dpi=150)
    plt.close()

    # ---- Graph 24: Cumulative key buffer over time ----
    plt.figure(figsize=(8, 5))
    plt.plot(segments, static_buffer, marker='o', label="Static (fixed p_z)", color="#909497")
    plt.plot(segments, anna_buffer, marker='s', label="ANNA-Adaptive", color="#28B463")
    plt.title("Cumulative Key Buffer Over the Dynamic-Channel Experiment")
    plt.xlabel("Segment")
    plt.ylabel("Cumulative Secret Key Buffer (bits)")
    plt.xticks(segments)
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("graphs/graph24_cumulative_key_buffer.png", dpi=150)
    plt.close()

    # ---- Graph 25: p_x chosen, static (fixed) vs ANNA (adaptive) ----
    plt.figure(figsize=(8, 5))
    plt.plot(segments, static_px, marker='o', label="Static p_x (fixed)", color="#909497")
    plt.plot(segments, anna_px, marker='s', label="ANNA p_x (adaptive)", color="#2E86C1")
    plt.plot(segments, [q/100 for q in true_qber], marker='^', linestyle='--',
              label="True channel QBER", color="#CB4335")
    plt.title("Test-Basis Probability (p_x): Fixed vs ANNA-Adaptive")
    plt.xlabel("Segment")
    plt.ylabel("Probability / QBER")
    plt.xticks(segments)
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("graphs/graph25_px_adaptation.png", dpi=150)
    plt.close()

    print("Graphs saved: graphs/graph23..25 "
          "(key length comparison, cumulative buffer, p_x adaptation)")


def main():
    random.seed(config.RANDOM_SEED)
    np.random.seed(config.RANDOM_SEED)
    rng = random.Random(config.RANDOM_SEED)

    print("=" * 90)
    print("EXPERIMENT: Static Baseline vs ANNA-Adaptive, same dynamic QBER schedule")
    print("=" * 90)

    print("\nRunning STATIC baseline (fixed p_z = {:.2f})...".format(config.P_Z_INITIAL))
    static_rows = run_static_baseline(QBER_SCHEDULE, rng)

    print("Running ANNA-ADAPTIVE (online control loop, no foreknowledge of future QBER)...")
    anna_rows, safety_log = run_anna_adaptive(QBER_SCHEDULE, rng)

    print_comparison_table(static_rows, anna_rows)

    static_accepted = sum(1 for r in static_rows if r["security_status"] == "ACCEPTED")
    anna_accepted = sum(1 for r in anna_rows if r["security_status"] == "ACCEPTED")
    static_total_key = static_rows[-1]["cumulative_key_buffer"]
    anna_total_key = anna_rows[-1]["cumulative_key_buffer"]

    print("\n" + "-" * 90)
    print(f"Segments ACCEPTED   -- Static: {static_accepted}/5   ANNA: {anna_accepted}/5")
    print(f"Total key generated -- Static: {static_total_key:.0f} bits   "
          f"ANNA: {anna_total_key:.0f} bits")
    print(f"Safety filter        -- unsafe_executed = {safety_log.summary()['unsafe_executed']} "
          f"(must be 0)")
    print("-" * 90)

    save_csv(static_rows, "static_baseline_results.csv", [])
    save_csv(anna_rows, "anna_adaptive_results.csv", ["requested_n_test", "t_epoch"])

    generate_comparison_graphs(static_rows, anna_rows)

    print("\n" + "=" * 90)
    if anna_total_key >= static_total_key and anna_accepted >= static_accepted:
        print("RESULT: ANNA-Adaptive matched or outperformed the static baseline "
              "on both key throughput and security acceptance.")
    else:
        print("RESULT: see the table above -- compare accepted-segment count and "
              "total key throughput between strategies.")
    print("=" * 90)


if __name__ == "__main__":
    main()
