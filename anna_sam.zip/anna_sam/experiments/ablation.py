"""
===========================================================
experiments/ablation.py

The A0-A3 ablation study:

    A0 = Static Std
    A1 = Adaptive Basis
    A2 = Adaptive Basis + Adaptive Test Allocation
    A3 = Full ANNA-SAM (+ Adaptive Rekey)

Each configuration runs through the SAME dynamic QBER
schedule used in main.py and experiments/dynamic_channel_
comparison.py, as a genuine online control loop (no
foreknowledge of the upcoming segment's true QBER -- each
controller only reacts to what it observed in the previous
epoch).

Run:
    python experiments/ablation.py
===========================================================
"""

import csv
import os
import random
import sys

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import config
from main import run_epoch
from quantum.channel import DynamicQBERSchedule

from anna.state import ANNAState
from anna.safety_filter import safety_filter, SafetyFilterLog

from baselines.static_std import make_controller as make_a0
from baselines.adaptive_basis import make_controller as make_a1
from baselines.adaptive_resource import make_controller as make_a2
from anna.controller import ANNAController


# NOTE ON SCHEDULE SCALE: main.py's QBER_SCHEDULE uses very large
# per-segment budgets (50000/37500 qubits) so that even the static
# baseline's fixed p_x=0.10 comfortably clears N_TEST_MIN=500 test
# rounds. That's the right choice for validating Phase 1+2 in
# isolation, but it means the ANNA controller's n_test target (500-
# 1500) is essentially ALWAYS already satisfied by the baseline
# budget alone -- so compute_epoch_budget() below would never
# actually need to spend extra qubits, and A1/A2/A3 would tie by
# construction rather than by a genuine finding. To make the
# resource-cost tradeoff that n_test/adapt_test is meant to
# demonstrate actually visible, this ablation study uses a SMALLER
# per-segment budget (same QBER progression, 1/2.5x the qubit
# count) where the baseline p_x's natural test yield is genuinely
# below what a higher-QBER-triggered n_test request asks for.
ABLATION_SCHEDULE = DynamicQBERSchedule([
    (20000, 0.01),
    (20000, 0.03),
    (20000, 0.06),
    (15000, 0.10),
    (15000, 0.02),
])


CONFIGURATIONS = [
    ("A0_Static", make_a0),
    ("A1_AdaptiveBasis", make_a1),
    ("A2_AdaptiveBasisTest", make_a2),
    ("A3_FullANNASAM", lambda: ANNAController()),  # all three flags True (default)
]


MAX_BUDGET_MULTIPLIER = 3.0   # cap extra rounds spent chasing n_test at 3x baseline


def compute_epoch_budget(baseline_n_rounds, p_x, requested_n_test, adapt_test):
    """
    Returns the actual qubit budget for this epoch. Only
    configurations with adapt_test=True (A2, A3) ever spend
    MORE than the fixed baseline budget -- and only when the
    controller's requested n_test wouldn't already be met at
    the baseline budget and chosen p_x. This is what makes
    n_test an actual, physically consequential action
    component rather than a logged-but-unused number, and is
    what allows A1 (adapt_test=False) to differ from A2/A3.
    """
    if not adapt_test or p_x <= 0:
        return baseline_n_rounds

    expected_n_x_at_baseline = baseline_n_rounds * (p_x ** 2)
    if requested_n_test <= expected_n_x_at_baseline:
        return baseline_n_rounds

    extra_rounds_needed = (requested_n_test - expected_n_x_at_baseline) / (p_x ** 2)
    total = baseline_n_rounds + extra_rounds_needed
    total = min(total, baseline_n_rounds * MAX_BUDGET_MULTIPLIER)

    return int(total)


def run_configuration(controller, schedule, rng):
    """
    A0/A1 (adapt_test=False) use the SAME fixed per-segment
    round budget from `schedule`. A2/A3 (adapt_test=True) may
    spend EXTRA rounds beyond that baseline when the
    controller requests a larger n_test than the baseline
    budget would naturally yield -- see compute_epoch_budget().
    This is what gives n_test a real, physically consequential
    effect, so A1 and A2/A3 are not forced to tie by construction.
    """
    log = SafetyFilterLog()

    state = ANNAState(
        qber=0.0, key_rate=0.0, packet_loss=0.0, key_buffer=0.0,
        receiver_count=config.NUM_RECEIVERS, group_change=0,
    )

    rows = []
    key_buffer = 0.0

    for seg_idx, baseline_n_rounds, true_qber in schedule.iter_segments():
        proposed = controller.select_action(state)
        safe_action = safety_filter(proposed, state, log=log)

        actual_n_rounds = compute_epoch_budget(
            baseline_n_rounds, safe_action["p_x"], safe_action["n_test"],
            controller.adapt_test,
        )

        result = run_epoch(actual_n_rounds, true_qber, p_z=safe_action["p_z"], rng=rng)

        key_buffer += result["secret_length"]
        key_rate = result["secret_length"] / actual_n_rounds if actual_n_rounds > 0 else 0.0

        rows.append({
            "segment": seg_idx,
            "true_qber": true_qber,
            "baseline_n_rounds": baseline_n_rounds,
            "n_rounds_used": actual_n_rounds,
            "p_z": safe_action["p_z"],
            "p_x": safe_action["p_x"],
            "n_test_requested": safe_action["n_test"],
            "t_epoch": safe_action["t_epoch"],
            "secret_length": result["secret_length"],
            "security_status": result["security_status"],
            "cumulative_key_buffer": key_buffer,
        })

        state = ANNAState(
            qber=result["q_x"], key_rate=key_rate, packet_loss=0.0,
            key_buffer=key_buffer, receiver_count=config.NUM_RECEIVERS,
            group_change=0,
        )

    return rows, log


def main():
    print("=" * 90)
    print("PHASE 6: ABLATION STUDY -- A0 (Static) vs A1 vs A2 vs A3 (Full ANNA-SAM)")
    print("=" * 90)

    all_results = {}

    for label, factory in CONFIGURATIONS:
        random.seed(config.RANDOM_SEED)
        np.random.seed(config.RANDOM_SEED)
        rng = random.Random(config.RANDOM_SEED)

        controller = factory()
        rows, log = run_configuration(controller, ABLATION_SCHEDULE, rng)
        all_results[label] = rows

        accepted = sum(1 for r in rows if r["security_status"] == "ACCEPTED")
        total_key = rows[-1]["cumulative_key_buffer"]
        print(f"\n{label}: {accepted}/5 segments accepted, "
              f"{total_key:.0f} total bits, "
              f"unsafe_executed={log.summary()['unsafe_executed']}")

    print("\n" + "-" * 90)
    print(f"{'Segment':>7} | {'True QBER':>9} | " +
          " | ".join(f"{label:>18}" for label, _ in CONFIGURATIONS))
    print("-" * 90)

    for i in range(5):
        qber = all_results[CONFIGURATIONS[0][0]][i]["true_qber"]
        row_str = f"{i:>7} | {qber*100:>8.1f}% | "
        row_str += " | ".join(
            f"{all_results[label][i]['secret_length']:>10} "
            f"{all_results[label][i]['security_status']:>7}"
            for label, _ in CONFIGURATIONS
        )
        print(row_str)

    save_results(all_results)
    generate_ablation_graphs(all_results)

    a1_tot = all_results["A1_AdaptiveBasis"][-1]["cumulative_key_buffer"]
    a2_tot = all_results["A2_AdaptiveBasisTest"][-1]["cumulative_key_buffer"]
    a3_tot = all_results["A3_FullANNASAM"][-1]["cumulative_key_buffer"]
    a1_rounds = sum(r["n_rounds_used"] for r in all_results["A1_AdaptiveBasis"])
    a2_rounds = sum(r["n_rounds_used"] for r in all_results["A2_AdaptiveBasisTest"])
    a3_rounds = sum(r["n_rounds_used"] for r in all_results["A3_FullANNASAM"])

    print(f"\nTotal qubits transmitted -- A1: {a1_rounds}, A2: {a2_rounds}, A3: {a3_rounds}")
    print("(A2/A3 may spend more than A1's fixed budget when requesting a "
          "larger test-sample size -- this is the resource cost behind any "
          "extra key throughput or acceptance they achieve over A1.)")

    if a1_tot == a2_tot == a3_tot and a1_rounds == a2_rounds == a3_rounds:
        print("\nNOTE: A1, A2, and A3 produced IDENTICAL results AND spent "
              "identical qubit budgets in this run -- meaning the requested "
              "n_test never actually exceeded what A1's fixed budget already "
              "yielded at the chosen p_x for any segment in this schedule.")

    print("\n" + "=" * 90)
    print("ABLATION STUDY COMPLETE")
    print("=" * 90)


def save_results(all_results):
    if not os.path.exists("results/raw"):
        os.makedirs("results/raw")

    path = "results/raw/ablation_study.csv"
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["config", "segment", "true_qber", "baseline_n_rounds", "n_rounds_used", "p_z", "p_x",
                          "n_test_requested", "t_epoch", "secret_length",
                          "security_status", "cumulative_key_buffer"])
        for label, rows in all_results.items():
            for r in rows:
                writer.writerow([
                    label, r["segment"], r["true_qber"], r["baseline_n_rounds"], r["n_rounds_used"],
                    r["p_z"], r["p_x"], r["n_test_requested"], r["t_epoch"],
                    r["secret_length"], r["security_status"], r["cumulative_key_buffer"],
                ])

    print(f"\nSaved: {path}")


def generate_ablation_graphs(all_results):
    if not os.path.exists("graphs"):
        os.makedirs("graphs")

    labels = [label for label, _ in CONFIGURATIONS]
    colors = ["#909497", "#F5B041", "#2E86C1", "#28B463"]

    # ---- Graph 29: Total key generated per configuration ----
    totals = [all_results[label][-1]["cumulative_key_buffer"] for label in labels]
    accepted_counts = [
        sum(1 for r in all_results[label] if r["security_status"] == "ACCEPTED")
        for label in labels
    ]

    fig, ax1 = plt.subplots(figsize=(9, 5))
    bars = ax1.bar(labels, totals, color=colors)
    ax1.set_ylabel("Total Key Generated (bits)")
    ax1.set_title("Ablation Study: Total Key Throughput and Segments Accepted")
    for bar, acc in zip(bars, accepted_counts):
        ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height(),
                  f"{acc}/5 accepted", ha='center', va='bottom', fontsize=9)
    plt.xticks(rotation=10)
    plt.grid(axis='y')
    plt.tight_layout()
    plt.savefig("graphs/graph29_ablation_total_key.png", dpi=150)
    plt.close()

    # ---- Graph 30: Cumulative key buffer over segments, all 4 configs ----
    plt.figure(figsize=(9, 5.5))
    segments = list(range(5))
    for label, color in zip(labels, colors):
        buffers = [all_results[label][i]["cumulative_key_buffer"] for i in segments]
        plt.plot(segments, buffers, marker='o', label=label, color=color)
    plt.title("Cumulative Key Buffer: A0 vs A1 vs A2 vs A3")
    plt.xlabel("Segment")
    plt.ylabel("Cumulative Secret Key Buffer (bits)")
    plt.xticks(segments)
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("graphs/graph30_ablation_cumulative_buffer.png", dpi=150)
    plt.close()

    # ---- Graph 31: Segments accepted per configuration ----
    plt.figure(figsize=(7, 5))
    plt.bar(labels, accepted_counts, color=colors)
    plt.title("Segments Accepted out of 5 (Security Gate Passed)")
    plt.ylabel("Segments Accepted")
    plt.ylim(0, 5)
    plt.xticks(rotation=10)
    plt.grid(axis='y')
    plt.tight_layout()
    plt.savefig("graphs/graph31_ablation_segments_accepted.png", dpi=150)
    plt.close()

    # ---- Graph 35: Total qubits spent per configuration (resource cost) ----
    total_rounds = [
        sum(r["n_rounds_used"] for r in all_results[label]) for label in labels
    ]
    plt.figure(figsize=(7, 5))
    plt.bar(labels, total_rounds, color=colors)
    plt.title("Total Qubits Transmitted (Resource Cost) per Configuration")
    plt.ylabel("Total Qubits")
    plt.xticks(rotation=10)
    plt.grid(axis='y')
    plt.tight_layout()
    plt.savefig("graphs/graph35_ablation_qubit_cost.png", dpi=150)
    plt.close()

    print("Graphs saved: graphs/graph29..31, graph35 "
          "(total key, cumulative buffer, segments accepted, qubit cost -- all A0-A3)")


if __name__ == "__main__":
    main()
