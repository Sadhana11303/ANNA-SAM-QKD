"""
===========================================================
config.py

Central configuration for ANNA-SAM (Phase 1 & 2)
All experimental parameters live here -- do not scatter
these values throughout the code.
===========================================================
"""

NUM_RECEIVERS = 8
N_TOTAL = 10000

P_Z_INITIAL = 0.90
P_X_INITIAL = 0.10

P_X_MIN = 0.05
N_TEST_MIN = 500

QBER_MAX = 0.11

EPS_SEC_MAX = 1e-10
EPS_COR_MAX = 1e-10
EPS_PE = 1e-10

KEY_BLOCK_SIZE = 128

BUFFER_MIN = 4096

NUM_RUNS = 30
RANDOM_SEED = 42

# Error-correction efficiency factor (Cascade-style overhead, typical 1.1-1.2x
# the Shannon limit)
EC_EFFICIENCY = 1.16

# Static (A0) baseline action reference values, per the ablation study spec.
# Used whenever a given ANNAController adaptive dimension is switched off.
STATIC_N_TEST = 1000
STATIC_T_EPOCH = 100
