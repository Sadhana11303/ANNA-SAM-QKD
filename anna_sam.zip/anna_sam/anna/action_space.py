"""
===========================================================
anna/action_space.py

Defines allowable values for ANNA's proposed action:

    0 <= p_z, p_x <= 1
    p_z + p_x == 1
    n_test >= N_TEST_MIN
    t_epoch > 0

validate_action() raises AssertionError if the action is
outside these bounds -- it is the formal definition of
"unsafe" that safety_filter.py enforces.
===========================================================
"""

import config


def validate_action(action):
    assert 0 <= action["p_z"] <= 1, "p_z out of [0,1]"
    assert 0 <= action["p_x"] <= 1, "p_x out of [0,1]"

    assert abs(action["p_z"] + action["p_x"] - 1) < 1e-9, \
        "p_z + p_x must equal 1"

    assert action["n_test"] >= config.N_TEST_MIN, \
        f"n_test below N_TEST_MIN ({config.N_TEST_MIN})"

    assert action["t_epoch"] > 0, "t_epoch must be positive"


def is_valid(action):
    """
    Non-raising convenience wrapper around validate_action(),
    used by safety_filter.py to detect unsafe actions without
    needing a try/except at every call site.
    """
    try:
        validate_action(action)
        return True
    except AssertionError:
        return False
