"""
===========================================================
anna/state.py

s_t = [Q_t, R_t, L_t, B_t, N_t, DeltaG_t]

The observable state ANNA sees before proposing an action.
Notice there is no congestion predictor here -- ANNA is a
controller, not a network-load forecaster.
===========================================================
"""

from dataclasses import dataclass


@dataclass
class ANNAState:
    qber: float            # Q_t  -- most recent measured QBER (Q_X)
    key_rate: float         # R_t  -- recent secret key generation rate
    packet_loss: float       # L_t  -- channel/link packet loss estimate
    key_buffer: float        # B_t  -- current buffered key material (bits)
    receiver_count: int       # N_t  -- active receivers in the multicast group
    group_change: int         # DeltaG_t -- 1 if group membership changed this epoch, else 0
