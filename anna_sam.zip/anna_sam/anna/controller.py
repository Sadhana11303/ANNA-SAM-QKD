"""
===========================================================
anna/controller.py

The ANNA controller: given the current state s_t, proposes
an action a_t = [p_z, p_x, n_test, t_epoch].

Per the guideline: "For the first implementation, do not use
deep reinforcement learning immediately." This is a rule-
based (heuristic) controller so the rest of the pipeline can
be tested before a learned policy is introduced. Swap
select_action()'s internals for an RL policy later without
changing any other module -- callers only depend on the
input/output shapes.

ABLATION SUPPORT: the three adaptive dimensions (basis,
test-allocation, rekey-epoch) can each be independently
switched on/off via adapt_basis / adapt_test / adapt_rekey.
This lets one controller class produce all four configurations
used in the Phase 6 ablation study:

    A0 = Static Std          (all False)
    A1 = Adaptive Basis       (adapt_basis=True only)
    A2 = A1 + Adaptive Test   (adapt_basis=True, adapt_test=True)
    A3 = Full ANNA-SAM        (all True) -- this is also the
                                default, i.e. plain
                                ANNAController() behaves exactly
                                as it did before this ablation
                                support was added.
===========================================================
"""

import config


class ANNAController:
    def __init__(self,
                 qber_max=config.QBER_MAX,
                 p_x_min=config.P_X_MIN,
                 n_test_min=config.N_TEST_MIN,
                 adapt_basis=True,
                 adapt_test=True,
                 adapt_rekey=True):
        self.qber_max = qber_max
        self.p_x_min = p_x_min
        self.n_test_min = n_test_min
        self.adapt_basis = adapt_basis
        self.adapt_test = adapt_test
        self.adapt_rekey = adapt_rekey

    def select_action(self, state):
        """
        state: an anna.state.ANNAState instance

        Returns a proposed action dict (may be UNSAFE --
        safety_filter.py is responsible for correcting it
        before it ever reaches the QKD engine).
        """
        qber_ratio = 0.0
        if self.qber_max > 0:
            qber_ratio = min(state.qber / self.qber_max, 1.0)

        # --- Basis probability: adaptive or fixed static baseline ---
        if self.adapt_basis:
            # Baseline is config.P_X_INITIAL (the static operating
            # point), NOT self.p_x_min -- p_x_min is a hard SAFETY
            # floor enforced by safety_filter.py, not a sensible
            # controller starting point. Only request MORE test
            # allocation as observed QBER rises.
            p_x = config.P_X_INITIAL + qber_ratio * (0.5 - config.P_X_INITIAL)
            p_x = max(self.p_x_min, min(p_x, 0.5))
        else:
            p_x = config.P_X_INITIAL   # A0/A... static value, e.g. 0.10
        p_z = 1.0 - p_x

        # --- Test allocation: adaptive or fixed static baseline ---
        if self.adapt_test:
            n_test = int(self.n_test_min * (1 + 2 * qber_ratio))
        else:
            n_test = config.STATIC_N_TEST   # A0/A1's fixed target

        # --- Rekey epoch: adaptive or fixed static baseline ---
        if self.adapt_rekey:
            base_t_epoch = config.STATIC_T_EPOCH
            if state.qber > self.qber_max * 0.5 or state.key_buffer < config.BUFFER_MIN:
                t_epoch = max(10, base_t_epoch // 2)
            elif qber_ratio < 0.2:
                t_epoch = base_t_epoch * 2
            else:
                t_epoch = base_t_epoch
        else:
            t_epoch = config.STATIC_T_EPOCH   # A0/A1/A2's fixed value

        return {
            "p_z": p_z,
            "p_x": p_x,
            "n_test": n_test,
            "t_epoch": t_epoch,
        }
