"""
===========================================================
anna/safety_filter.py

The boundary between ANNA and cryptography:

    a_t^prop -> F_sec -> a_t^safe

ANNA's proposed action is clamped into the valid action
space defined by action_space.py before it is ever allowed
to reach the QKD engine. This module logs:

    unsafe proposed
    unsafe corrected
    unsafe executed

The required invariant is N_unsafe,executed = 0 -- i.e. an
unsafe action must NEVER be the one actually run.
===========================================================
"""

import config
from anna.action_space import is_valid


class SafetyFilterLog:
    def __init__(self):
        self.total_actions = 0
        self.unsafe_proposed = 0
        self.unsafe_corrected = 0
        self.unsafe_executed = 0   # must remain 0 by construction

    def record(self, proposed_was_unsafe, final_is_safe):
        self.total_actions += 1
        if proposed_was_unsafe:
            self.unsafe_proposed += 1
            if final_is_safe:
                self.unsafe_corrected += 1
        if not final_is_safe:
            self.unsafe_executed += 1

    def summary(self):
        return {
            "total_actions": self.total_actions,
            "unsafe_proposed": self.unsafe_proposed,
            "unsafe_corrected": self.unsafe_corrected,
            "unsafe_executed": self.unsafe_executed,
        }


def safety_filter(action, state=None, log=None):
    """
    action: proposed action dict (possibly unsafe)
    state : optional ANNAState (unused by the current simple
            clamping rules, but kept in the signature so a
            future state-dependent safety policy can use it
            without changing the call sites)
    log   : optional SafetyFilterLog to record statistics
    """
    proposed_was_unsafe = not is_valid(action)

    safe = dict(action)

    # Clamp p_x to its floor, recompute p_z to keep them summing to 1
    safe["p_x"] = min(max(safe.get("p_x", config.P_X_MIN), config.P_X_MIN), 1.0)
    safe["p_z"] = 1.0 - safe["p_x"]

    # Clamp n_test to its floor
    safe["n_test"] = max(safe.get("n_test", config.N_TEST_MIN), config.N_TEST_MIN)

    # t_epoch must be strictly positive
    safe["t_epoch"] = max(safe.get("t_epoch", 1), 1)

    final_is_safe = is_valid(safe)

    if log is not None:
        log.record(proposed_was_unsafe, final_is_safe)

    # This assertion is the module's own guarantee: whatever it
    # returns must always satisfy the action space, or the pipeline
    # should fail loudly rather than silently run an unsafe action.
    assert final_is_safe, "safety_filter produced an action that still fails validation"

    return safe
