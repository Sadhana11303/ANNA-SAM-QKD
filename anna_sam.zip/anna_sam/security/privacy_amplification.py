"""
===========================================================
security/privacy_amplification.py

Universal hashing: K_i = Hash(K_EC,i), truncated to the
secure length l_i computed by finite_key.py.

Uses a counter-based extendable hash (HKDF-Expand style) so
the output is never silently capped at a single hash
digest's length (e.g. 256 bits for SHA-256) regardless of
how large l_i is.
===========================================================
"""

import hashlib


def privacy_amplification(key_bits, output_length):
    """
    key_bits      : the error-corrected key (list of 0/1)
    output_length : l_i, the secure key length from finite_key.py

    Returns the final key as a bitstring of length output_length
    (or shorter if key_bits is empty / output_length <= 0).
    """
    if output_length <= 0 or len(key_bits) == 0:
        return ""

    bit_string = "".join(str(b) for b in key_bits)
    byte_data = int(bit_string, 2).to_bytes(
        (len(bit_string) + 7) // 8, byteorder="big"
    )

    hash_bits = ""
    counter = 0
    while len(hash_bits) < output_length:
        digest = hashlib.sha256(byte_data + counter.to_bytes(4, "big")).digest()
        hash_bits += "".join(f"{byte:08b}" for byte in digest)
        counter += 1

    return hash_bits[:output_length]
