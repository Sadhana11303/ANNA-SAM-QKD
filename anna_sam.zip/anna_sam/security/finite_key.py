"""
===========================================================
security/finite_key.py

Finite-key secret-key-length calculation:

    l <= H_min^eps_s(X | E) - leak_EC - Delta_fin

SIMULATION NOTE:
This implements a representative GLLP/Tomamichel-style
finite-key formula (the standard structural form: entropy
term minus EC leakage minus a security correction term).
If your chosen security proof uses a different exact bound,
replace calculate_secret_key_length() below.

This module must be deterministic. ANNA must never modify
this security bound.
===========================================================
"""

import math

from security.error_correction import binary_entropy


def calculate_secret_key_length(n_z, phase_error_upper,
                                 leak_ec, epsilon_sec, epsilon_cor):
    """
    n_z              : size of the key-generation sample
    phase_error_upper: e_X^U from parameter_estimation.py
    leak_ec          : bits leaked during error correction
    epsilon_sec       : target secrecy failure probability
    epsilon_cor       : target correctness failure probability

    Returns the achievable secret key length l_i (int, >= 0).
    """
    if n_z <= 0:
        return 0

    h = binary_entropy(min(phase_error_upper, 0.5))

    correction_term = (
        2 * math.log2(1.0 / (2 * epsilon_sec))
        + math.log2(2.0 / epsilon_cor)
    )

    length = n_z * (1 - h) - leak_ec - correction_term

    return max(0, int(length))
