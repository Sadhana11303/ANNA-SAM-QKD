"""
===========================================================
security/security_gate.py

The boundary that decides whether a generated key is
accepted or aborted. ANNA cannot override this.

S_i = I(eps_sec,i <= eps_sec_max) * I(eps_cor,i <= eps_cor_max) * I(l_i > 0)
===========================================================
"""


def security_gate(secret_length, epsilon_sec, epsilon_cor, config):
    security_ok = (
        secret_length > 0
        and epsilon_sec <= config.EPS_SEC_MAX
    )

    correctness_ok = (
        epsilon_cor <= config.EPS_COR_MAX
    )

    return security_ok and correctness_ok
