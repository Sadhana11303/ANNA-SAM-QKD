"""
===========================================================
security/error_correction.py

Simulation abstraction for K_Z^raw -> K_EC. At minimum we
must calculate leak_EC (the information revealed to a
potential eavesdropper during error correction), since
finite_key.py needs this to compute the secure key length.

leak_EC = f_EC * n_Z * h2(E_Z)

where f_EC is the Cascade-style efficiency factor (>= 1,
typically 1.1-1.2x the Shannon limit) and h2 is the binary
entropy function.

Can later be replaced by an actual LDPC/Cascade
implementation if needed -- callers only depend on
error_correction()'s return signature.
===========================================================
"""

import math


def binary_entropy(x):
    if x <= 0.0 or x >= 1.0:
        return 0.0
    return -x * math.log2(x) - (1 - x) * math.log2(1 - x)


def error_correction(alice_key_bits, bob_key_bits, efficiency=1.16):
    """
    alice_key_bits, bob_key_bits: Z-basis raw key bits
        (Alice's/Head-End's ground truth, Bob's/receiver's
        raw noisy version)
    efficiency: Cascade-style overhead factor f_EC

    Returns (corrected_bob_key, leak_ec, e_z):
        corrected_bob_key -- Bob's key after (simulated,
            assumed-successful) reconciliation against Alice's
        leak_ec -- bits of information leaked over the public
            channel during reconciliation
        e_z -- the observed key-basis error rate (diagnostic
            only; never revealed as part of the live protocol)
    """
    n_z = len(alice_key_bits)

    if n_z == 0:
        return [], 0.0, 0.0

    errors = sum(a != b for a, b in zip(alice_key_bits, bob_key_bits))
    e_z = errors / n_z

    leak_ec = efficiency * n_z * binary_entropy(e_z)

    # Simulate successful reconciliation: Bob's key now matches
    # Alice's (this is what real Cascade/LDPC achieves when
    # e_z is within the code's correction capacity).
    corrected_bob_key = list(alice_key_bits)

    return corrected_bob_key, leak_ec, e_z
