"""
===========================================================
security/parameter_estimation.py

Finite-sample upper bound on the phase error rate:

    e_X^U = PEBound(Q_X, n_X, n_Z, eps_PE)

SIMULATION NOTE:
This implements a representative Serfling-type finite-key
statistical bound, the standard structural form used across
BB84/E91 finite-key security literature (e.g. Tomamichel et
al.). If your chosen security proof specifies a different
exact bound, replace phase_error_upper_bound() below --
callers only depend on its signature and range [0, 0.5].

ANNA must NEVER call or influence this module.
===========================================================
"""

import math


def phase_error_upper_bound(q_x, n_x, n_z, epsilon_pe):
    """
    q_x     : measured error rate on the X-basis test sample
    n_x     : size of the test sample (|test_rounds|)
    n_z     : size of the key-generation sample (|key_rounds|)
    epsilon_pe : parameter-estimation failure probability

    Returns the upper-bounded phase error rate e_X^U,
    capped at 0.5 (maximal uncertainty).
    """
    if n_x <= 0 or n_z <= 0:
        # Cannot estimate at all -- treat as maximally insecure
        return 0.5

    numerator = (n_x + n_z) * (n_z + 1)
    denominator = n_x * (n_z ** 2)

    if denominator <= 0:
        return 0.5

    mu = math.sqrt((numerator / denominator) * math.log(1.0 / epsilon_pe))

    bound = q_x + mu
    return min(bound, 0.5)
